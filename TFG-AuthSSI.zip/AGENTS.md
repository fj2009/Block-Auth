# Autenticación SSI sobre Ethereum local (TFG) — Hardhat 3 + ethers

TFG de Telecomunicaciones: sustituir los servidores centrales de identidad (RADIUS/AD) por SSI
sobre una blockchain Ethereum **local** (cero gas, sin internet). La cadena es sólo fuente de
verdad (identidad, revocación, RBAC); la verificación criptográfica ocurre fuera de cadena, en
el Agente (proxy Python).

## Layout

```
contracts/          Solidity: IdentityRegistry, RevocationRegistry, AccessPolicyRegistry
test/               Tests Mocha+Chai (TS) vía network.create() — en proceso, sin nodo externo
ignition/modules/   AccessStack.ts: despliega los 3 contratos (Hardhat Ignition)
scripts/            seed.ts + demo-client.ts + lib/deployments.ts
                    + provision-cardi.mjs (aprovissiona CARDI: wallet + keystore cifrado)
proxy/              Agente de autenticación (Python/FastAPI) — .venv propio, puerto 8001,
                    sirve la web (proxy/web/, vendored ethers local, login por
                    usuario+contraseña que cifra/descifra el keystore en el navegador) y los
                    endpoints /auth/register, /auth/status, /auth/verify, /query, /files/*
infra/              PostgreSQL 16 en Docker, puerto 5433 (no 5432)
docs/               decisiones (DEC-xx), fases y errores — material de la memoria
hardhat.config.ts   solc 0.8.34, perfiles {default, production(optimizer)}
```

## Commands

- **Instalador (dependencias de las dos fases):** `./instalar.sh` — npm + compilar + tests + venv del Proxy.
- **Arranque completo en dos fases:** `./arrancar-sistema.sh start|stop|restart|status|reset|log [proxy|blockchain|db]`
  - Fase 1 · blockchain: `./iniciar.sh start` (nodo 8545 + `ignition deploy --reset` + seed).
  - Fase 2 · aplicación: elige la BD del Proxy — `1)` predeterminada (contenedor postgres local,
    vía `levantar-db.sh`), `2)` ya montada (no la toca), `3)` personalizada (host/puerto/usuario/clave
    propios) → escribe `proxy/.env`. Reanuda el proxy SIEMPRE (la Fase 1 con `--reset` cambia las
    direcciones de los contratos; un proxy ya en marcha quedaría apuntando a la cadena vieja).
    Automatizable: `DB_CHOICE=default|existing|custom` (+ variables `DB_*` para custom).
  - Aprovisiona el usuario demo **CARDI**: `node scripts/provision-cardi.mjs` genera una wallet nueva,
    la inscribe como `did:web:tfg:cardi` (ROLE_VIEWER) vía `/auth/register` y guarda la clave privada
    CIFRADA con su contraseña en `proxy/web/static/keystore-cardi.json` (formato
    pbkdf2-sha256 + aes-256-gcm compatible con WebCrypto). Cada `start` = cadena limpia + CARDI fresco.
- Tests (en proceso, efímeros, no necesitan nodo): `npx hardhat test` (o `npm test`)
- Typecheck: `npx hardhat build` regenera los tipos TypeChain en `types/` (gitignored), luego
  `npx tsc --noEmit`. OJO: `tsc --noEmit` **reporta errores preexistentes** en `test/*.ts`
  (helpers tipados como `Wallet` vs `HardhatEthersSigner`); los tests pasan vía hardhat igualmente,
  no persigas un `tsc` limpio de todo el repo.
- Demo completa — nodo (8545, chain id 31337) + despliegue + seed:
  - `./iniciar.sh start|status|stop|reset|log`
  - equivale a `npx hardhat node --port 8545` + `npx hardhat ignition deploy
    ignition/modules/AccessStack.ts --network localhost` + `npx hardhat run
    scripts/seed.ts --network localhost` (seed idempotente)
- Base de datos: `./infra/levantar-db.sh start|stop|status` (db `tfg`, usuarios `rol_viewer`/`rol_analyst`)
- Proxy (requiere nodo + despliegue + DB activos): `./proxy/arrancar.sh start|stop|status`

## Gotchas (documentados en `docs/errores/`)

- **Nunca `pkill -f` con un patrón que aparezca en la propia línea de comandos** (p. ej.
  `pkill -f "hardhat node"`): se mata el propio shell (Errores #3/#6). Parar procesos con
  `./iniciar.sh stop` o `kill $(cat .hardhat-node.pid)`.
- **Nonces (Errores #4/#5):** el nodo local hace automining y la caché de nonce de ethers va
  desfasada respecto al nodo. Para varias txs secuenciales de un mismo firmante, leer el nonce
  vivo por JSON-RPC crudo en cada envío:
  `provider.send("eth_getTransactionCount", [address, "pending"])`. No «simplifiques»
  `broadcast()` en `scripts/seed.ts` de vuelta a `provider.getTransactionCount`.
- **ethers v6 bytes (Error #2):** salidas/eventos del contrato devuelven `string` hex; las
  entradas aceptan `Uint8Array`. Comparar siempre contra `ethers.hexlify(input)`.
- **web3.py bytes32 (Error #8):** `w3.keccak(...).hex()` NO incluye `0x`; los args `bytes32` de
  contratos lo exigen → usa `w3.to_hex(w3.keccak(...))` como formato canónico tanto al escribir
  como al leer getters. Además `can(dh, tabla, op)` del Proxy espera `op` como nombre
  («read»/«write»/«delete»), no el entero de la máscara.
- **Colisión con AccessControl (DEC-09):** `AccessPolicyRegistry` usa a propósito
  `assignRole`/`unassignRole` (no los `grantRole`/`revokeRole` de OZ) para evitar ABI ambigua.
  Mantén ese naming al ampliar.
- RBAC: roles `ROLE_ADMIN/WRITER/VIEWER/ANALYST`; máscara de ops READ=1, WRITE=2, DELETE=4;
  DID = `keccak256(did)`; el owner es una dirección Ethereum; la rotación firma
  `keccak256(didHash, newOwner)` con la clave anterior (EIP-191/eth_sign).
- Las claves privadas de `hardhat.config.ts` (localhost) y `scripts/seed.ts` son las cuentas
  estándar de la frase semilla de `hardhat node` — solo desarrollo.
- Docs, comentarios y mensajes de commit se escriben en **castellano** (convención del repo).

## Working in this project

Cuando escribas o modifiques tests, configures `hardhat.config.ts` o interactúes con la red
desde TypeScript, invoca la skill **`hardhat`**. Cubre tests Solidity y TypeScript, cuándo
elegir cada capa, cheatcodes de `forge-std`, la API `network.create()`, `networkHelpers` y el
flujo compile-then-typecheck. La skill apunta a la skill `hardhat-toolbox-*` homóloga según el
toolbox (signers, interacción con contratos, assertions).

## Docs

- Hardhat 3 — https://hardhat.org/llms.txt
- ethers.js — https://docs.ethers.org/v6/
- Decisiones de diseño: `docs/01-decisiones.md`; fases: `docs/fases/`; errores:
  `docs/errores/` (registra los nuevos ahí, son material de la memoria).