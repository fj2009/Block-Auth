#!/usr/bin/env bash
# Instalador del sistema SSI (dependencias de las DOS fases):
#   Fase 1 · blockchain : dependencias npm + compilación + tests (Hardhat/ethers)
#   Fase 2 · aplicación : entorno virtual del Proxy + requirements (FastAPI/web3)
#
# Posteriormente arranque en dos fases: ./arrancar-sistema.sh start
set -euo pipefail

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$ROOT"

if ! command -v npm >/dev/null 2>&1; then
  echo "ERROR: npm no esta instalado." >&2
  exit 1
fi

echo "[1/4] Instalando dependencias (Fase 1 · blockchain)..."
npm install

if ! npx --no-install esbuild --version >/dev/null 2>&1; then
  echo "      Aprobando scripts de postinstall de esbuild (npm 11)..."
  npm install-scripts approve esbuild 2>/dev/null || true
  npm install
fi

npx esbuild --version >/dev/null 2>&1 || {
  echo "ERROR: esbuild no compilo correctamente durante la instalacion." >&2
  exit 1
}

echo "[2/4] Compilando contratos..."
npx hardhat compile

echo "[3/4] Ejecutando tests..."
npx hardhat test

echo "[4/4] Entorno del Proxy (Fase 2 · aplicacion)..."
python3 -m venv proxy/.venv
proxy/.venv/bin/pip install -q --disable-pip-version-check -r proxy/requirements.txt
touch proxy/.venv/.deps.done

echo ""
echo "Instalacion completada. Arranque en dos fases con: ./arrancar-sistema.sh start"
echo "  Fase 1 · blockchain  ->  ./iniciar.sh start"
echo "  Fase 2 · aplicacion  ->  ./arrancar-sistema.sh start (elige la BD)"