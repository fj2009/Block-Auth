CREATE ROLE rol_viewer LOGIN PASSWORD 'viewer_dev_pass';
CREATE ROLE rol_analyst LOGIN PASSWORD 'analyst_dev_pass';

CREATE TABLE diagnosticos (
  id SERIAL PRIMARY KEY,
  paciente TEXT NOT NULL,
  diagnostico TEXT NOT NULL,
  medico TEXT NOT NULL,
  creado TIMESTAMPTZ NOT NULL DEFAULT now()
);

INSERT INTO diagnosticos (paciente, diagnostico, medico) VALUES
  ('Ana Ruiz',    'Gripe estacional',        'Doctor A'),
  ('Luis Gómez',  'Migraña crónica',         'Doctor A'),
  ('Marta Peña',  'Alergia alimentaria',     'Doctor A'),
  ('Iván Soler',  'Hipertensión leve',       'Doctor A');

CREATE TABLE ventas (
  id SERIAL PRIMARY KEY,
  producto TEXT NOT NULL,
  unidades INT NOT NULL,
  importe NUMERIC(10,2) NOT NULL
);

INSERT INTO ventas (producto, unidades, importe) VALUES
  ('Termómetro digital', 12, 89.88),
  ('Oxímetro',           7,  104.93),
  ('Tensiómetro',        3,  179.97),
  ('Mascarilla (x50)',   25, 42.50);

GRANT SELECT ON diagnosticos TO rol_viewer;
GRANT SELECT ON ventas TO rol_analyst;

-- Archivos personales del usuario (acceso por propietario, sin RLS:
-- el Proxy filtra por DID del titular). El rol de BD usará el que
-- corresponda a la sesión (viewer o analyst); ambos necesitan CRUD aquí.
CREATE TABLE IF NOT EXISTS archivos (
  id SERIAL PRIMARY KEY,
  owner_hash TEXT NOT NULL,
  did TEXT NOT NULL,
  nombre TEXT NOT NULL,
  contenido BYTEA NOT NULL,
  creado TIMESTAMPTZ NOT NULL DEFAULT now()
);
GRANT SELECT, INSERT, UPDATE, DELETE ON archivos TO rol_viewer;
GRANT USAGE, SELECT ON SEQUENCE archivos_id_seq TO rol_viewer;
GRANT SELECT, INSERT, UPDATE, DELETE ON archivos TO rol_analyst;
GRANT USAGE, SELECT ON SEQUENCE archivos_id_seq TO rol_analyst;