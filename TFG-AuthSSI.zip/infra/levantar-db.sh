#!/usr/bin/env bash
set -euo pipefail

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
NAME="db-tfg"
IMAGE="postgres:16-alpine"
VOLUME="tfg-pgdata"
PORT=5433
INIT="$ROOT/infra/postgres/init.sql"

dg() {
  if id -nG | tr ' ' '\n' | grep -qx docker; then
    docker "$@"
  else
    sg docker -c "docker $(printf '%q ' "$@")"
  fi
}

running() {
  dg ps --filter "name=^${NAME}$" --format '{{.Status}}' 2>/dev/null | grep -q Up
}

exists() {
  dg ps -a --filter "name=^${NAME}$" --format '{{.Names}}' 2>/dev/null | grep -qx "$NAME"
}

wait_ready() {
  local i
  for i in $(seq 1 40); do
    if dg exec "$NAME" pg_isready -U postgres -d tfg >/dev/null 2>&1; then
      echo "Base de datos lista en 127.0.0.1:$PORT (db=tfg)."
      return 0
    fi
    sleep 0.5
  done
  echo "ERROR: postgres no ha quedado listo." >&2
  return 1
}

case "${1:-}" in
  start)
    if running; then
      echo "Contenedor $NAME ya esta en marcha."
      wait_ready
      exit 0
    fi
    if exists; then
      echo "Reanudando contenedor $NAME..."
      dg start "$NAME"
    else
      echo "Creando contenedor $NAME (postgres:16-alpine)..."
      dg run -d --name "$NAME" \
        --restart unless-stopped \
        -e POSTGRES_PASSWORD=tfg_admin_dev_pass \
        -e POSTGRES_DB=tfg \
        -p "127.0.0.1:${PORT}:5432" \
        -v "${VOLUME}:/var/lib/postgresql/data" \
        -v "${INIT}:/docker-entrypoint-initdb.d/010-init.sql:ro" \
        "$IMAGE" >/dev/null
      echo "Contenedor creado."
    fi
    wait_ready
    ;;
  stop)
    if running; then
      dg stop "$NAME" >/dev/null
      echo "Contenedor $NAME parado."
    else
      echo "Contenedor $NAME no estaba en marcha."
    fi
    ;;
  status)
    if running; then
      echo "PostgreSQL: ACTIVO  ($NAME, 127.0.0.1:$PORT, db=tfg)"
      dg exec "$NAME" psql -U postgres -d tfg -tAc "SELECT rolname FROM pg_roles;" 2>/dev/null \
        | grep '^rol_' | sed 's/^/  usuario: /' || true
      dg exec "$NAME" psql -U postgres -d tfg -tAc "SELECT relname FROM pg_stat_user_tables;" 2>/dev/null \
        | sed 's/^/  tabla:   /' || true
    else
      echo "PostgreSQL: PARADO"
    fi
    ;;
  log)
    dg logs -f "$NAME"
    ;;
  *)
    echo "Uso: $0 {start|stop|status|log}"
    exit 1
    ;;
esac