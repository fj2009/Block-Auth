import { writeFileSync, mkdirSync, readFileSync } from "node:fs";
import path from "node:path";
import { network } from "hardhat";
import { ethers } from "ethers";
import { stackAddress } from "./lib/deployments.js";

/**
 * Seed de la demo (Módulo 2) sobre el nodo local.
 *
 * Crea el escenario médico del TFG:
 *   - Doctor A    -> VIEWER  (solo lectura sobre "diagnosticos")
 *   - Analista    -> ANALYST (solo lectura sobre "ventas")
 *   - Intruso     -> sin identidad registrada
 *
 * y ejecuta el "momento mágico": retirar el rol del Doctor en caliente
 * (1 tx) -> can() niega; conceder de nuevo -> can() permite.
 *
 * Requiere: nodo local levantado y el stack desplegado.
 *
 * Uso: npx hardhat run scripts/seed.ts --network localhost
 */
const { ethers: hhEthers } = await network.create({ network: "localhost" });
const RPC = "http://127.0.0.1:8545";

// --- Claves privadas de las cuentas estándar de `hardhat node` ---
const PRIVATE_KEYS: Record<string, string> = {
  admin: "0xac0974bec39a17e36ba4a6b4d238ff944bacb478cbed5efcae784d7bf4f2ff80",
  doctorA: "0x59c6995e998f97a5a0044966f0945389dc9e86dae88c7a8412f4603b6b78690d",
  analyst: "0x5de4111afa1a4b94908f83103eb1f1706367c2e68ca870fc3fb9a804cdab365a",
  intruso: "0x7c852118294e51e653712a81e05800f419141751be58f605c371e15141b007a6",
};

const producer = new ethers.JsonRpcProvider(RPC);
const walletOf = (name: string) => new ethers.Wallet(PRIVATE_KEYS[name], producer);

function loadContract(name: "IdentityRegistry" | "RevocationRegistry" | "AccessPolicyRegistry", signer: ethers.Wallet) {
  const artifact = JSON.parse(
    readFileSync(path.join(process.cwd(), "artifacts", "contracts", `${name}.sol`, `${name}.json`), "utf8"),
  );
  return new ethers.Contract(stackAddress(name), artifact.abi, signer);
}

/**
 * Envía una transacción con NONCE EXPLÍCITO obtenido por JSON-RPC CRUDO en el
 * momento del envío (Errores #4/#5 documentados): `provider.getTransactionCount`
 * de ethers va 1 por detrás del estado del nodo (caché interna del provider),
 * y un nonce inválido se rechaza con NONCE_EXPIRED. La llamada RPC directa
 * devuelve siempre el valor vigente.
 */
async function broadcast(
  wallet: ethers.Wallet,
  invoke: (overrides: { nonce: number }) => Promise<ethers.ContractTransactionResponse>,
) {
  const nonce = Number(
    await producer.send("eth_getTransactionCount", [wallet.address, "pending"]),
  );
  const tx = await invoke({ nonce });
  await tx.wait();
  return tx;
}

// --- DIDs de demo ---
const DIDS = {
  doctorA: "did:web:tfg:demo:doctorA",
  analyst: "did:web:tfg:demo:analyst",
  intruso: "did:web:tfg:demo:intruso",
};

// --- Constantes de operaciones (deben coincidir con el contrato) ---
const OP_READ = 1;
const OP_WRITE = 2;
const OP_DELETE = 4;

const admin = walletOf("admin");
const identityRegistry = loadContract("IdentityRegistry", admin);
const revocationRegistry = loadContract("RevocationRegistry", admin);
const acl = loadContract("AccessPolicyRegistry", admin);

const ROLE_VIEWER = await acl.ROLE_VIEWER();
const ROLE_ANALYST = await acl.ROLE_ANALYST();

console.log("Contratos desplegados:");
console.log("  IdentityRegistry     :", stackAddress("IdentityRegistry"));
console.log("  RevocationRegistry   :", stackAddress("RevocationRegistry"));
console.log("  AccessPolicyRegistry :", stackAddress("AccessPolicyRegistry"));

// --- 1) Registrar identidades (DID -> wallet). El intruso NO se registra
// (intruso = identidad no reconocida en la blockchain). ---
console.log("\n> Registrando identidades en IdentityRegistry...");
for (const name of ["doctorA", "analyst"] as const) {
  const wallet = walletOf(name);
  const hash = ethers.id(DIDS[name]);
  if (await identityRegistry.isRegistered(hash)) {
    console.log(`  ${name}: ya registrado (skip, seed idempotente)`);
    continue;
  }
  const tx = await broadcast(admin, (o) => identityRegistry.registerDID(hash, wallet.address, o));
  console.log(`  ${name}: ${DIDS[name]} -> ${wallet.address} (${tx.hash.slice(0, 18)}...)`);
}

// --- 2) Políticas rol -> tabla -> operación ---
console.log("\n> Configurando políticas (roles -> tablas -> operaciones)...");
const OP_ALL = OP_READ | OP_WRITE | OP_DELETE;
await broadcast(admin, (o) => acl.setPolicy(ROLE_VIEWER, "diagnosticos", OP_READ, o));
await broadcast(admin, (o) => acl.setPolicy(ROLE_ANALYST, "ventas", OP_READ, o));
await broadcast(admin, (o) => acl.setPolicy(ROLE_VIEWER, "archivos", OP_ALL, o));
await broadcast(admin, (o) => acl.setPolicy(ROLE_ANALYST, "archivos", OP_ALL, o));
console.log("  VIEWER  -> diagnosticos { read } y archivos { read|write|delete }");
console.log("  ANALYST -> ventas         { read } y archivos { read|write|delete }");

// --- 3) Asignar roles ---
console.log("\n> Asignando roles de organización...");
await broadcast(admin, (o) => acl.assignRole(ethers.id(DIDS.doctorA), ROLE_VIEWER, o));
await broadcast(admin, (o) => acl.assignRole(ethers.id(DIDS.analyst), ROLE_ANALYST, o));
console.log("  doctorA -> ROLE_VIEWER");
console.log("  analyst -> ROLE_ANALYST");

// --- 4) Tabla de permisos resultante ---
console.log("\n=== Permisos resultantes (oráculo can()) ===");
const checks: [string, string, number][] = [
  ["doctorA", "diagnosticos", OP_READ],
  ["doctorA", "diagnosticos", OP_WRITE],
  ["doctorA", "diagnosticos", OP_DELETE],
  ["doctorA", "ventas", OP_READ],
  ["analyst", "ventas", OP_READ],
  ["analyst", "diagnosticos", OP_READ],
  ["intruso", "diagnosticos", OP_READ],
];
for (const [who, tabla, op] of checks) {
  const perm = await acl.can(ethers.id(DIDS[who as keyof typeof DIDS]), tabla, op);
  const opName = op === OP_READ ? "READ" : op === OP_WRITE ? "WRITE" : "DELETE";
  console.log(`  ${who.padEnd(8)} ${tabla.padEnd(14)} ${opName.padEnd(6)} -> ${perm ? "PERMITIDO" : "DENEGADO"}`);
}

// --- 5) MOMENTO MÁGICO: revocar y restituir en caliente ---
console.log("\n=== Momento mágico (revocación y restitución en caliente) ===");
const doctorHash = ethers.id(DIDS.doctorA);
console.log("> Doctor A lee diagnosticos          ->", await acl.can(doctorHash, "diagnosticos", OP_READ));

const txRevoke = await broadcast(admin, (o) => acl.unassignRole(doctorHash, o));
console.log(`> TX unassignRole(doctorA): ${txRevoke.hash.slice(0, 18)}...`);
console.log("> Doctor A lee diagnosticos AHORA    ->", await acl.can(doctorHash, "diagnosticos", OP_READ), "(acceso retirado)");

const txGrant = await broadcast(admin, (o) => acl.assignRole(doctorHash, ROLE_VIEWER, o));
console.log(`> TX assignRole(doctorA): ${txGrant.hash.slice(0, 18)}...`);
console.log("> Doctor A lee diagnosticos DE NUEVO ->", await acl.can(doctorHash, "diagnosticos", OP_READ), "(acceso restituido)");

// --- 6) Persistir mapa de usuarios demo para el Módulo 4 (cliente) ---
const demoUsers = Object.fromEntries(
  Object.entries(DIDS).map(([name, dId]) => [
    name,
    { did: dId, didHash: ethers.id(dId), privateKey: PRIVATE_KEYS[name], address: walletOf(name).address },
  ]),
);
const outDir = path.join(process.cwd(), "scripts", "seeds");
mkdirSync(outDir, { recursive: true });
writeFileSync(path.join(outDir, "demo-users.json"), JSON.stringify(demoUsers, null, 2));
console.log("\n✅ Mapa de usuarios demo guardado en scripts/seeds/demo-users.json");