import { createCipheriv, pbkdf2Sync, randomBytes } from "node:crypto";
import { writeFileSync } from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";
import { Wallet } from "ethers";

/**
 * Aprovisiona el usuario demo CARDI:
 *   - genera una wallet, la inscribe en la cadena como did:web:tfg:cardi
 *     (roles vía el Proxy /auth/register, admin firma en cadena) y
 *   - guarda la clave privada CIFRADA con una contraseña (keystore
 *     PBKDF2+AES-GCM, compatible con WebCrypto del navegador).
 *
 * El keystore se publica en proxy/web/static/keystore-<alias>.json para que
 * la web lo descargue y lo descifre en el navegador con la contraseña; la
 * firma de autenticación sigue haciéndola el cliente (SSI).
 *
 * Idempotente: si el DID ya está registrado, /auth/register no lo duplica.
 */

const PASSWORD = process.env.CARDI_PASSWORD || "cardofj2009";
const ALIAS = (process.env.CARDI_ALIAS || "cardi").toLowerCase().replace(/[^a-z0-9-]/g, "");
const DID = `did:web:tfg:${ALIAS}`;
const PROXY = process.env.PROXY_URL || "http://127.0.0.1:8001";

const KDF_ITERATIONS = 150000;
const ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..");

function keystoreCifrado(privada, password) {
  const salt = randomBytes(16);
  const key = pbkdf2Sync(Buffer.from(password, "utf8"), salt, KDF_ITERATIONS, 32, "sha256");
  const iv = randomBytes(12);
  const cipher = createCipheriv("aes-256-gcm", key, iv);
  const ct = Buffer.concat([
    cipher.update(Buffer.from(privada, "utf8")),
    cipher.final(),
  ]);
  const tag = cipher.getAuthTag();
  return {
    did: DID,
    address: "",
    kdf: "pbkdf2-sha256",
    iterations: KDF_ITERATIONS,
    salt: salt.toString("base64"),
    cipher: "aes-256-gcm",
    iv: iv.toString("base64"),
    ct: ct.toString("base64"),
    tag: tag.toString("base64"),
  };
}

async function main() {
  console.log(`\n=== Aprovisionando usuario demo: ${DID} ===`);

  const wallet = Wallet.createRandom();
  console.log(`  dirección generada: ${wallet.address}`);

  const res = await fetch(`${PROXY}/auth/register`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ did: DID, address: wallet.address }),
  });
  const data = await res.json().catch(() => ({}));
  if (!res.ok) {
    console.error(`  ERROR registrando en cadena (HTTP ${res.status}): ${data.error || "?"}`);
    process.exit(1);
  }
  console.log(`  identidad=${DID} rol=${data.rol} didHash=${data.didHash?.slice(0, 12)}…`);

  const ks = keystoreCifrado(wallet.privateKey, PASSWORD);
  ks.address = wallet.address;
  const outDir = path.join(ROOT, "proxy", "web", "static");
  const outFile = path.join(outDir, `keystore-${ALIAS}.json`);
  writeFileSync(outFile, JSON.stringify(ks, null, 2));
  console.log(`  keystore cifrado  -> ${path.relative(ROOT, outFile)}`);

  console.log("");
  console.log("  Usuario : " + DID);
  console.log("  Password: " + (PASSWORD.length ? "********" : "(vacía)"));
  console.log("  Para entrar: http://127.0.0.1:8001/ -> Entrar");
}

main().catch((e) => {
  console.error("  ERROR:", e instanceof Error ? e.message : e);
  process.exit(1);
});