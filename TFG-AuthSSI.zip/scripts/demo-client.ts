import { readFileSync } from "node:fs";
import path from "node:path";
import { Wallet, JsonRpcProvider, keccak256, toUtf8Bytes, getBytes } from "ethers";

const RPC = process.env.CHAIN_RPC || "http://127.0.0.1:8545";
const PROXY = process.env.PROXY_URL || "http://127.0.0.1:8001";
const DEMO_USER = process.env.DEMO_USER || "doctorA";
const DEMO_SQL = process.env.DEMO_SQL || "";
const DEMO_REPLAY = process.env.DEMO_REPLAY === "1";

const users = JSON.parse(
  readFileSync(path.join(process.cwd(), "scripts", "seeds", "demo-users.json"), "utf8"),
);
const user = users[DEMO_USER];
if (!user) {
  console.error(`Usuario demo no existe: ${DEMO_USER} (disponibles: ${Object.keys(users).join(", ")})`);
  process.exit(1);
}

const sql =
  DEMO_SQL ||
  (DEMO_USER === "analyst" ? "SELECT * FROM ventas;" : "SELECT * FROM diagnosticos;");

let counter = 0;
const payload = {
  sql,
  nonce: `${Date.now()}-${++counter}`,
  ts: Math.floor(Date.now() / 1000),
};
const payloadRaw = JSON.stringify(payload);

const provider = new JsonRpcProvider(RPC);
const wallet = new Wallet(user.privateKey, provider);
const digest = keccak256(toUtf8Bytes(payloadRaw));
const firma = await wallet.signMessage(getBytes(digest));

console.log(`\n${DEMO_USER} (${user.did}) firmando consulta: ${sql}`);
console.log(`  signer:    ${wallet.address === user.address ? "coincide con el DID" : "INCONSISTENTE"}`);
console.log(`  firma:     ${firma.slice(0, 20)}...`);

async function post(endpoint: string, body: unknown) {
  const res = await fetch(`${PROXY}${endpoint}`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(body),
  });
  const text = await res.text();
  let data: unknown = {};
  try {
    data = JSON.parse(text);
  } catch {
    data = text;
  }
  return { status: res.status, data };
}

const verify = await post("/auth/verify", { did: user.did, payload: payloadRaw, firma });
console.log(`\nPOST /auth/verify -> HTTP ${verify.status}`);
console.log(JSON.stringify(verify.data, null, 2));

if (verify.status !== 200) {
  process.exit(DEMO_REPLAY ? 0 : 1);
}

const token = (verify.data as { jwt: string }).jwt;
const q = await post("/query", { jws: token, sql });
console.log(`\nPOST /query -> HTTP ${q.status}`);
console.log(JSON.stringify(q.data, null, 2));

if (DEMO_REPLAY) {
  const replay = await post("/auth/verify", { did: user.did, payload: payloadRaw, firma });
  console.log(`\nReplay (misma firma) -> HTTP ${replay.status} (esperado 403)`);
}