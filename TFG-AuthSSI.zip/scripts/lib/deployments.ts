import { readdirSync, readFileSync } from "node:fs";
import path from "node:path";

/**
 * Localiza las direcciones desplegadas por Hardhat Ignition.
 * Ignition guarda por red `chain-<id>/deployed_addresses.json` con el nombre
 * de módulo#contrato como clave (p. ej. "AccessStackModule#IdentityRegistry").
 */
export function findDeployedAddresses(): Record<string, string> {
  const deploymentsRoot = path.join(process.cwd(), "ignition", "deployments");
  const chainDir = readdirSync(deploymentsRoot).find((d) => d.startsWith("chain-"));
  if (!chainDir) throw new Error("No deployments found. Run: npx hardhat ignition deploy ignition/modules/AccessStack.ts --network localhost");

  const file = path.join(deploymentsRoot, chainDir, "deployed_addresses.json");
  return JSON.parse(readFileSync(file, "utf8"));
}

/** Dirección de un contrato concreto del stack de acceso. */
export function stackAddress(name: "IdentityRegistry" | "RevocationRegistry" | "AccessPolicyRegistry"): string {
  const found = findDeployedAddresses();
  const entry = Object.entries(found).find(([key]) => key.endsWith(`#${name}`));
  if (!entry) throw new Error(`${name} not deployed yet.`);
  return entry[1];
}