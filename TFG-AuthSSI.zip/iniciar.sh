#!/usr/bin/env bash
set -euo pipefail

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$ROOT"

PORT=8545
RPC="http://127.0.0.1:${PORT}"
PIDFILE="$ROOT/.hardhat-node.pid"
LOGFILE="$ROOT/.hardhat-node.log"

rpc_up() {
  curl -sf -m 2 -X POST -H 'Content-Type: application/json' \
    -d '{"jsonrpc":"2.0","method":"eth_blockNumber","params":[],"id":1}' \
    "$RPC" >/dev/null 2>&1
}

block_number() {
  curl -s -m 2 -X POST -H 'Content-Type: application/json' \
    -d '{"jsonrpc":"2.0","method":"eth_blockNumber","params":[],"id":1}' "$RPC" 2>/dev/null \
    | tr -d '"{} ' | sed 's/.*result://'
}

pid_alive() {
  [ -f "$PIDFILE" ] && kill -0 "$(head -n1 "$PIDFILE")" 2>/dev/null
}

start_node() {
  if rpc_up; then
    echo "Nodo ya activo en $RPC (bloque $(block_number))."
    return 0
  fi
  echo "Arrancando nodo blockchain en $RPC..."
  nohup "$ROOT/node_modules/.bin/hardhat" node --port "$PORT" >>"$LOGFILE" 2>&1 &
  echo $! > "$PIDFILE"
  local i
  for i in $(seq 1 60); do
    rpc_up && { echo "Nodo listo (bloque $(block_number))."; return 0; }
    sleep 0.5
  done
  echo "ERROR: el nodo no respondio a tiempo. Vea $LOGFILE" >&2
  exit 1
}

deploy_and_seed() {
  echo "Desplegando contratos (--reset)..."
  npx hardhat ignition deploy ignition/modules/AccessStack.ts --network localhost --reset
  echo "Sembrando la demo..."
  npx hardhat run scripts/seed.ts --network localhost
  echo "Despliegue y seed completados."
}

stop_node() {
  if pid_alive; then
    kill "$(head -n1 "$PIDFILE")"
    rm -f "$PIDFILE"
    local i
    for i in $(seq 1 20); do
      rpc_up || { echo "Nodo parado."; return 0; }
      sleep 0.5
    done
    echo "ERROR: el nodo sigue activo tras el kill." >&2
    exit 1
  fi
  if rpc_up; then
    echo "Hay un nodo en $RPC pero sin PID registrado; no se puede parar de forma segura." >&2
    exit 1
  fi
  echo "El nodo no estaba en marcha."
}

status_info() {
  echo "== Estado del sistema =="
  if rpc_up; then
    echo "Nodo:      ACTIVO  ($RPC, bloque $(block_number))"
    if pid_alive; then
      echo "  PID:     $(cat "$PIDFILE")"
    else
      echo "  PID:     sin registrar (proceso externo)"
    fi
  else
    echo "Nodo:      PARADO"
  fi

  if [ -f ignition/deployments/chain-31337/deployed_addresses.json ]; then
    echo "Contratos (registro local):"
    sed 's/^\(  "\)\?/    /' ignition/deployments/chain-31337/deployed_addresses.json \
      | tr -d '"{},' | sed '/^$/d'
  else
    echo "Contratos: no desplegados todavia."
  fi

  if [ -f scripts/seeds/demo-users.json ]; then
    echo "Identidades sembradas:"
    grep -oE '"did": "[^"]+"' scripts/seeds/demo-users.json | sed 's/"did": "//; s/"//; s/^/    /'
  fi
}

case "${1:-}" in
  start)
    start_node
    deploy_and_seed
    status_info
    ;;
  stop)
    stop_node
    ;;
  restart)
    stop_node
    start_node
    deploy_and_seed
    status_info
    ;;
  reset)
    stop_node
    rm -rf ignition/deployments
    start_node
    deploy_and_seed
    status_info
    ;;
  status)
    status_info
    ;;
  log)
    if [ -f "$LOGFILE" ]; then
      tail -f "$LOGFILE"
    else
      echo "Sin log todavia."
    fi
    ;;
  *)
    echo "Uso: $0 {start|stop|restart|reset|status|log}"
    exit 1
    ;;
esac