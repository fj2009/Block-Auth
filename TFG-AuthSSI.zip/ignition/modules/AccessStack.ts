import { buildModule } from "@nomicfoundation/hardhat-ignition/modules";

/**
 * Despliegue del "stack de acceso" completo en un solo módulo:
 * IdentityRegistry + RevocationRegistry + AccessPolicyRegistry.
 * Un único comando para la demo: los tres contratos quedan enlazados
 * lógicamente (el Proxy los consulta) y con dirección conocida.
 */
export default buildModule("AccessStackModule", (m) => {
  const identityRegistry = m.contract("IdentityRegistry");
  const revocationRegistry = m.contract("RevocationRegistry");
  const accessPolicyRegistry = m.contract("AccessPolicyRegistry");

  return { identityRegistry, revocationRegistry, accessPolicyRegistry };
});