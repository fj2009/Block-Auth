import json
import re
import threading
import time
from collections import deque
from contextlib import asynccontextmanager
from urllib.parse import quote

import jwt
import psycopg
import uvicorn
from eth_account import Account
from eth_account.messages import encode_defunct
from fastapi import FastAPI, File, Request, UploadFile
from fastapi.responses import FileResponse, JSONResponse, Response
from fastapi.staticfiles import StaticFiles
from psycopg.rows import dict_row
from web3 import Web3

import config

w3 = Web3(Web3.HTTPProvider(config.CHAIN_RPC, request_kwargs={"timeout": 5}))

OP = {"read": 1, "write": 2, "delete": 4}
OP_VERB = {"select": "read", "insert": "write", "update": "write", "delete": "delete"}
ROLES = ("ROLE_ADMIN", "ROLE_WRITER", "ROLE_VIEWER", "ROLE_ANALYST")
ROLE_BYTES = {r: w3.to_hex(w3.keccak(text=r)) for r in ROLES}
ROLE_BY_BYTES = {v: k for k, v in ROLE_BYTES.items()}
ROLES_WITH_DB = ("ROLE_VIEWER", "ROLE_ANALYST")
TABLAS = ("diagnosticos", "ventas", "archivos")


def _load_abi(name: str):
    path = config.ROOT / "artifacts" / "contracts" / f"{name}.sol" / f"{name}.json"
    return json.loads(path.read_text())["abi"]


identity = w3.eth.contract(address=config.IDENTITY_ADDRESS, abi=_load_abi("IdentityRegistry"))
revocation = w3.eth.contract(address=config.REVOCATION_ADDRESS, abi=_load_abi("RevocationRegistry"))
acl = w3.eth.contract(address=config.ACL_ADDRESS, abi=_load_abi("AccessPolicyRegistry"))

_owner_cache = {}
_registered_cache = {}
_revoked_cache = {}
_role_cache = {}
_used_nonces = deque(maxlen=10000)


def _now():
    return time.monotonic()


def _fresh(kind, cache, key, value):
    cache[key] = (value, _now())


def _cached(kind, cache, key, fetch):
    hit = cache.get(key)
    if hit is not None and _now() - hit[1] < config.CACHE_TTL:
        return hit[0]
    value = fetch()
    cache[key] = (value, _now())
    return value


def did_hash(did: str) -> str:
    return "0x" + w3.keccak(text=did).hex()


def owner_of(dh: str) -> str:
    return _cached("owner", _owner_cache, dh, lambda: identity.functions.getOwner(dh).call().lower())


def is_registered(dh: str) -> bool:
    def fetch():
        return identity.functions.isRegistered(dh).call() and not identity.functions.isDeactivated(dh).call()

    return _cached("registered", _registered_cache, dh, fetch)


def is_revoked(dh: str) -> bool:
    return _cached("revoked", _revoked_cache, dh, lambda: revocation.functions.isRevoked(dh).call())


def role_of(dh: str):
    def fetch():
        rb = acl.functions.roleOf(dh).call()
        return ROLE_BY_BYTES.get(w3.to_hex(rb)) if rb != b"\x00" * 32 else None

    return _cached("role", _role_cache, dh, fetch)


def can(dh: str, tabla: str, op: str) -> bool:
    return acl.functions.can(dh, tabla, OP[op]).call()


def _check_payload(payload: dict):
    nonce = payload.get("nonce")
    if not isinstance(nonce, str) or not re.fullmatch(r"[A-Za-z0-9:_\-]{1,64}", nonce):
        raise PermissionError("nonce no valido")
    if nonce in _used_nonces:
        raise PermissionError("nonce ya usado (replay)")
    ts = payload.get("ts")
    if not isinstance(ts, (int, float)) or abs(time.time() - ts) > config.TS_TOLERANCE:
        raise PermissionError("timestamp fuera de la ventana ±%ss" % config.TS_TOLERANCE)
    _used_nonces.append(nonce)


def parse_sql(sql: str):
    if not isinstance(sql, str) or not sql.strip():
        raise ValueError("sql vacia")
    s = sql.strip()
    if s.endswith(";"):
        s = s[:-1].strip()
    if ";" in s:
        raise ValueError("solo una sentencia")
    m = re.match(r"^\s*(select|insert|update|delete)\b", s, re.I | re.S)
    if not m:
        raise ValueError("sentencia no reconocida")
    verb = m.group(1).lower()
    t = None
    if verb == "select":
        t = re.search(r"\bfrom\s+([a-z0-9_]+)", s, re.I)
    else:
        t = re.search(r"\b(?:into|update|from)\s+([a-z0-9_]+)", s, re.I)
    if not t:
        raise ValueError("tabla no detectada")
    tabla = t.group(1).lower()
    if tabla not in TABLAS:
        raise PermissionError(f"tabla {tabla} fuera del alcance")
    return tabla, verb


def verify_auth(did: str, payload_raw: str, firma: str):
    try:
        payload = json.loads(payload_raw)
    except ValueError:
        raise ValueError("payload no es JSON")
    _check_payload(payload)
    operacion = payload.get("sql")
    tabla, op = parse_sql(operacion)
    op_name = OP_VERB[op]
    dh = did_hash(did)
    digest = encode_defunct(primitive=bytes(w3.keccak(text=payload_raw)))
    signer = Account.recover_message(digest, signature=firma).lower()

    if not is_registered(dh):
        raise PermissionError("identidad no registrada en IdentityRegistry")
    if signer != owner_of(dh):
        raise PermissionError("la firma no corresponde al owner del DID")
    if is_revoked(dh):
        raise PermissionError("identidad revocada en RevocationRegistry")
    rol = role_of(dh)
    if rol is None:
        raise PermissionError("el DID no tiene rol asignado")
    if not can(dh, tabla, op_name):
        raise PermissionError(f"{rol} no puede {op_name} sobre {tabla}")
    token = jwt.encode(
        {"did": did, "dh": dh, "rol": rol, "exp": time.time() + config.JWT_TTL},
        config.JWT_SECRET,
        algorithm="HS256",
    )
    return {"jwt": token, "rol": rol, "did": did, "tabla": tabla, "op": op_name, "exp_seg": config.JWT_TTL}


def check_access(token: str):
    try:
        claims = jwt.decode(token, config.JWT_SECRET, algorithms=["HS256"])
    except jwt.InvalidTokenError:
        raise PermissionError("JWT invalido o caducado")
    dh = claims["dh"]
    rol = claims["rol"]
    if not is_registered(dh):
        raise PermissionError("identidad no registrada")
    if is_revoked(dh):
        raise PermissionError("identidad revocada (acceso cortado)")
    if role_of(dh) != rol:
        raise PermissionError(f"rol cambiado en cadena (ahora {role_of(dh)}), sesion no valida")
    return claims


def _bearer(authorization: str | None):
    if not authorization or not authorization.lower().startswith("bearer "):
        raise PermissionError("token requerido (Authorization: Bearer <jwt>)")
    return authorization.split(" ", 1)[1].strip()


def _conn_for(rol: str):
    if rol == "ROLE_VIEWER":
        dsn = config.VIEWER_DSN
    elif rol == "ROLE_ANALYST":
        dsn = config.ANALYST_DSN
    else:
        raise PermissionError(f"rol {rol} sin acceso de base de datos en esta demo")
    return psycopg.connect(dsn, row_factory=dict_row)


def _garantizar_politica_archivos():
    """Asegura la política READ|WRITE|DELETE sobre 'archivos' para los roles con BD.
    Idempotente: solo emite tx si falta algún bit. La firma la hace el NODO
    (cuenta admin desbloqueada), no este proceso."""
    mask = OP["read"] | OP["write"] | OP["delete"]
    for rol in ROLES_WITH_DB:
        if acl.functions.policies(ROLE_BYTES[rol], config.ARCHIVOS_TABLA).call() != mask:
            tx = acl.functions.setPolicy(ROLE_BYTES[rol], config.ARCHIVOS_TABLA, mask).transact(
                {"from": config.ADMIN_ADDRESS}
            )
            w3.eth.wait_for_transaction_receipt(tx)


_periodic_stop = threading.Event()


def _poller():
    cursor = w3.eth.block_number
    while not _periodic_stop.is_set():
        try:
            latest = w3.eth.block_number
            if latest > cursor:
                for log in revocation.events.Revoked.get_logs(fromBlock=cursor + 1, toBlock=latest):
                    dh = log["args"]["didHash"].hex()
                    _fresh("revoked", _revoked_cache, dh, True)
                for log in acl.events.RoleRevokedFor.get_logs(fromBlock=cursor + 1, toBlock=latest):
                    _fresh("role", _role_cache, log["args"]["didHash"].hex(), None)
                for log in acl.events.RoleGrantedFor.get_logs(fromBlock=cursor + 1, toBlock=latest):
                    _role_cache.pop(log["args"]["didHash"].hex(), None)
                cursor = latest
        except Exception:
            pass
        _periodic_stop.wait(0.5)


@asynccontextmanager
async def lifespan(_: FastAPI):
    thread = threading.Thread(target=_poller, daemon=True, name="chain-events")
    thread.start()
    yield
    _periodic_stop.set()


app = FastAPI(title="Proxy Validador — TFG", lifespan=lifespan)


@app.get("/health")
def health():
    return {
        "proxy": "ok",
        "chain": w3.is_connected(),
        "block": w3.eth.block_number,
        "db": config.DB_HOST + ":" + config.DB_PORT,
        "registries": {
            "IdentityRegistry": config.IDENTITY_ADDRESS,
            "RevocationRegistry": config.REVOCATION_ADDRESS,
            "AccessPolicyRegistry": config.ACL_ADDRESS,
        },
    }


def _error(status: int, msg: str):
    return JSONResponse({"error": msg}, status_code=status)


@app.post("/auth/verify")
async def auth_verify(req: Request):
    try:
        body = await req.json()
        did = body.get("did")
        payload_raw = body.get("payload")
        firma = body.get("firma")
        if not did or not payload_raw or not firma:
            return _error(400, "faltan campos: did, payload, firma")
        if not isinstance(did, str) or not isinstance(payload_raw, str) or not isinstance(firma, str):
            return _error(400, "did, payload y firma deben ser texto")
        return verify_auth(did, payload_raw, firma)
    except ValueError as e:
        return _error(400, str(e))
    except PermissionError as e:
        return _error(403, str(e))
    except Exception as e:
        return _error(500, f"error interno: {e}")


@app.post("/query")
async def query(req: Request):
    try:
        body = await req.json()
        jws = body.get("jws")
        sql = body.get("sql")
        if not jws or not sql:
            return _error(400, "faltan campos: jws, sql")
        claims = check_access(jws)
        rol, dh = claims["rol"], claims["dh"]
        if rol not in ROLES_WITH_DB:
            return _error(403, f"rol {rol} sin acceso de base de datos en esta demo")
        tabla, op = parse_sql(sql)
        if tabla == config.ARCHIVOS_TABLA:
            raise PermissionError("tabla 'archivos' se gestiona por los endpoints /files/*")
        if not can(dh, tabla, OP_VERB[op]):
            return _error(403, f"{rol} no puede {OP_VERB[op]} sobre {tabla}")
        dsn = config.VIEWER_DSN if rol == "ROLE_VIEWER" else config.ANALYST_DSN
        with psycopg.connect(dsn, row_factory=dict_row) as conn:
            with conn.cursor() as cur:
                cur.execute(sql)
                filas = cur.fetchall() if cur.description else []
        return {"rol": rol, "tabla": tabla, "op": op, "n": len(filas), "filas": filas}
    except ValueError as e:
        return _error(400, str(e))
    except PermissionError as e:
        return _error(403, str(e))
    except Exception as e:
        return _error(500, f"error interno: {e}")


@app.post("/auth/register")
async def auth_register(req: Request):
    """"Auto-registro" SSI: el usuario crea una wallet en el navegador y entrega
    su DID + dirección; este proxy (con la cuenta ADMIN del despliegue) inscribe
    la identidad en IdentityRegistry y le asigna ROLE_VIEWER si aún no tenía rol.
    La firma de las txs la hace el nodo local (cuenta admin desbloqueada), por lo
    que el nonce lo calcula el nodo en cada envío (evita la caché de nonces)."""
    try:
        body = await req.json()
        did = body.get("did")
        address = body.get("address")
        if not isinstance(did, str) or not did.strip():
            raise ValueError("campo 'did' requerido")
        if len(did) > 200:
            raise ValueError("did demasiado largo")
        if not isinstance(address, str) or not re.fullmatch(r"0x[0-9a-fA-F]{40}", address):
            raise ValueError("campo 'address' invalido (debe ser una wallet 0x...)")
        address = w3.to_checksum_address(address)
        dh = did_hash(did)

        if not identity.functions.isRegistered(dh).call():
            tx = identity.functions.registerDID(dh, address).transact({"from": config.ADMIN_ADDRESS})
            w3.eth.wait_for_transaction_receipt(tx)
        _garantizar_politica_archivos()
        if acl.functions.roleOf(dh).call() == b"\x00" * 32:
            tx = acl.functions.assignRole(dh, ROLE_BYTES["ROLE_VIEWER"]).transact(
                {"from": config.ADMIN_ADDRESS}
            )
            w3.eth.wait_for_transaction_receipt(tx)

        return {"ok": True, "did": did, "didHash": dh, "address": address, "rol": role_of(dh)}
    except ValueError as e:
        return _error(400, str(e))
    except PermissionError as e:
        return _error(403, str(e))
    except Exception as e:
        return _error(500, f"error interno: {e}")


@app.get("/auth/status")
async def auth_status(did: str = ""):
    """Estado on-chain de una identidad (usado por la web para evitar registrar
    un DID que ya existe, p. ej. el usuario demo aprovisionado CARDI)."""
    try:
        if not did or not isinstance(did, str) or len(did) > 200:
            raise ValueError("parametro 'did' requerido")
        dh = did_hash(did)
        registrado = identity.functions.isRegistered(dh).call()
        return {
            "did": did,
            "dh": dh,
            "registered": registrado,
            "deactivated": identity.functions.isDeactivated(dh).call(),
            "revoked": is_revoked(dh),
            "owner": (identity.functions.getOwner(dh).call().lower() if registrado else None),
            "rol": role_of(dh) if registrado else None,
        }
    except ValueError as e:
        return _error(400, str(e))
    except Exception as e:
        return _error(500, f"error interno: {e}")


@app.post("/files/upload")
async def files_upload(req: Request, archivo: UploadFile = File(...)):
    try:
        claims = check_access(_bearer(req.headers.get("authorization")))
        rol, dh = claims["rol"], claims["dh"]
        if rol not in ROLES_WITH_DB:
            raise PermissionError(f"rol {rol} sin acceso de archivos")
        if not can(dh, config.ARCHIVOS_TABLA, "write"):
            raise PermissionError(f"{rol} no puede escribir en {config.ARCHIVOS_TABLA}")
        nombre = (archivo.filename or "").rstrip().replace("\\", "/").rsplit("/", 1)[-1]
        if not nombre or nombre in (".", ".."):
            raise ValueError("nombre de archivo invalido")
        if len(nombre) > 255:
            nombre = nombre[-255:]
        contenido = await archivo.read()
        if not contenido:
            raise ValueError("archivo vacio")
        with _conn_for(rol) as conn:
            with conn.cursor() as cur:
                cur.execute(
                    f"INSERT INTO {config.ARCHIVOS_TABLA} (owner_hash, did, nombre, contenido) "
                    "VALUES (%s, %s, %s, %s) RETURNING id",
                    (dh, claims["did"], nombre, contenido),
                )
                fid = cur.fetchone()["id"]
        return {"ok": True, "id": fid, "nombre": nombre, "bytes": len(contenido)}
    except ValueError as e:
        return _error(400, str(e))
    except PermissionError as e:
        return _error(403, str(e))
    except Exception as e:
        return _error(500, f"error interno: {e}")


@app.get("/files/list")
async def files_list(req: Request):
    try:
        claims = check_access(_bearer(req.headers.get("authorization")))
        rol, dh = claims["rol"], claims["dh"]
        if rol not in ROLES_WITH_DB:
            raise PermissionError(f"rol {rol} sin acceso de archivos")
        if not can(dh, config.ARCHIVOS_TABLA, "read"):
            raise PermissionError(f"{rol} no puede leer {config.ARCHIVOS_TABLA}")
        with _conn_for(rol) as conn:
            with conn.cursor() as cur:
                cur.execute(
                    f"SELECT id, nombre, length(contenido)::int AS tamano, creado "
                    f"FROM {config.ARCHIVOS_TABLA} WHERE owner_hash = %s ORDER BY id DESC",
                    (dh,),
                )
                filas = cur.fetchall()
        return {"n": len(filas), "archivos": filas}
    except ValueError as e:
        return _error(400, str(e))
    except PermissionError as e:
        return _error(403, str(e))
    except Exception as e:
        return _error(500, f"error interno: {e}")


@app.get("/files/download/{fid}")
async def files_download(req: Request, fid: int):
    try:
        claims = check_access(_bearer(req.headers.get("authorization")))
        rol, dh = claims["rol"], claims["dh"]
        if rol not in ROLES_WITH_DB:
            raise PermissionError(f"rol {rol} sin acceso de archivos")
        if not can(dh, config.ARCHIVOS_TABLA, "read"):
            raise PermissionError(f"{rol} no puede leer {config.ARCHIVOS_TABLA}")
        with _conn_for(rol) as conn:
            with conn.cursor() as cur:
                cur.execute(
                    f"SELECT owner_hash, nombre, contenido FROM {config.ARCHIVOS_TABLA} WHERE id = %s",
                    (fid,),
                )
                fila = cur.fetchone()
        if not fila:
            raise ValueError("archivo no existe")
        if str(fila["owner_hash"]).lower() != dh.lower():
            raise PermissionError("el archivo no te pertenece")
        quirk = quote(fila["nombre"])
        return Response(
            content=fila["contenido"],
            media_type="application/octet-stream",
            headers={
                "Content-Disposition": (
                    f"attachment; filename*=UTF-8''{quirk}; filename=\"{fila['nombre']}\""
                )
            },
        )
    except ValueError as e:
        return _error(400, str(e))
    except PermissionError as e:
        return _error(403, str(e))
    except Exception as e:
        return _error(500, f"error interno: {e}")


@app.delete("/files/{fid}")
async def files_delete(req: Request, fid: int):
    try:
        claims = check_access(_bearer(req.headers.get("authorization")))
        rol, dh = claims["rol"], claims["dh"]
        if rol not in ROLES_WITH_DB:
            raise PermissionError(f"rol {rol} sin acceso de archivos")
        if not can(dh, config.ARCHIVOS_TABLA, "delete"):
            raise PermissionError(f"{rol} no puede borrar en {config.ARCHIVOS_TABLA}")
        with _conn_for(rol) as conn:
            with conn.cursor() as cur:
                cur.execute(
                    f"DELETE FROM {config.ARCHIVOS_TABLA} WHERE id = %s AND owner_hash = %s",
                    (fid, dh),
                )
                borrado = cur.rowcount
        if not borrado:
            raise ValueError("archivo no existe o no te pertenece")
        return {"ok": True, "id": fid}
    except ValueError as e:
        return _error(400, str(e))
    except PermissionError as e:
        return _error(403, str(e))
    except Exception as e:
        return _error(500, f"error interno: {e}")


WEB_DIR = config.ROOT / "proxy" / "web"
app.mount("/static", StaticFiles(directory=WEB_DIR / "static"), name="static")


@app.get("/")
async def index():
    return FileResponse(WEB_DIR / "index.html")


if __name__ == "__main__":
    uvicorn.run("main:app", host=config.PROXY_HOST, port=config.PROXY_PORT, log_level="info")