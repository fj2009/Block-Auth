const $ = (id) => document.getElementById(id);
const SQL_LOGIN = "SELECT * FROM archivos";

const KDF_ITERATIONS = 150000;
const SALT_BYTES = 16;
const IV_BYTES = 12;

const identidades = JSON.parse(localStorage.getItem("ssi_identidades") || "{}");
let sesion = JSON.parse(localStorage.getItem("ssi_sesion") || "null");

const guardarIds = () => localStorage.setItem("ssi_identidades", JSON.stringify(identidades));
const guardarSesion = () =>
  sesion ? localStorage.setItem("ssi_sesion", JSON.stringify(sesion))
         : localStorage.removeItem("ssi_sesion");

function sesionActiva() {
  return sesion && sesion.exp > Date.now();
}

function msg(el, texto, tipo) {
  const node = $(el);
  node.className = `msg ${tipo || ""}`;
  node.textContent = texto;
}

/* ---- utilidades binarias ---- */
function bytesToB64(bytes) {
  let s = "";
  bytes.forEach((b) => { s += String.fromCharCode(b); });
  return btoa(s);
}
function b64ToBytes(b64) {
  const s = atob(b64);
  const u = new Uint8Array(s.length);
  for (let i = 0; i < s.length; i++) u[i] = s.charCodeAt(i);
  return u;
}
function derivaAES(password, salt) {
  return crypto.subtle.importKey("raw", new TextEncoder().encode(password), "PBKDF2", false, ["deriveKey"])
    .then((km) => crypto.subtle.deriveKey(
      { name: "PBKDF2", salt: b64ToBytes(salt), iterations: KDF_ITERATIONS, hash: "SHA-256" },
      km,
      { name: "AES-GCM", length: 256 },
      false,
      ["encrypt", "decrypt"],
    ));
}

async function cifrarKeystore(privada, password) {
  const salt = new Uint8Array(SALT_BYTES);
  crypto.getRandomValues(salt);
  const iv = new Uint8Array(IV_BYTES);
  crypto.getRandomValues(iv);
  const key = await derivaAES(password, bytesToB64(salt));
  const cta = await crypto.subtle.encrypt({ name: "AES-GCM", iv }, key, new TextEncoder().encode(privada));
  const ctb = new Uint8Array(cta);                       // ciphertext || (GCM tag)
  const ct = ctb.slice(0, ctb.length - 16);
  const tag = ctb.slice(ctb.length - 16);
  return {
    kdf: "pbkdf2-sha256",
    iterations: KDF_ITERATIONS,
    salt: bytesToB64(salt),
    cipher: "aes-256-gcm",
    iv: bytesToB64(iv),
    ct: bytesToB64(ct),
    tag: bytesToB64(tag),
  };
}

async function descifrarKeystore(ks, password) {
  const key = await derivaAES(password, ks.salt);
  const ct = b64ToBytes(ks.ct);
  const tag = b64ToBytes(ks.tag);
  const combined = new Uint8Array(ct.length + tag.length);
  combined.set(ct);
  combined.set(tag, ct.length);
  const plain = await crypto.subtle.decrypt({ name: "AES-GCM", iv: b64ToBytes(ks.iv) }, key, combined);
  return new TextDecoder().decode(plain);
}

/* ---- fuentes de keystore: navegador (localStorage) o aprovisionado (/static) ---- */
const keystoreCache = {};

async function getKeystore(did) {
  if (keystoreCache[did]) return keystoreCache[did];
  if (identidades[did]) {
    const id = identidades[did];
    keystoreCache[did] = { did, address: id.address, keystore: id.keystore };
    return keystoreCache[did];
  }
  const alias = did.startsWith("did:web:tfg:") ? did.slice("did:web:tfg:".length) : did;
  if (!/^[a-z0-9-]+$/.test(alias)) throw new Error("usuario no reconocido");
  const res = await fetch(`/static/keystore-${alias}.json`);
  if (res.status === 404) throw new Error(`no existe clave guardada para "${alias}"`);
  if (!res.ok) throw new Error("no se pudo obtener el keystore de " + alias);
  const ks = await res.json();
  keystoreCache[did] = { did, address: ks.address || "", keystore: ks };
  return keystoreCache[did];
}

async function estadoOnChain(did) {
  const res = await fetch(`/auth/status?did=${encodeURIComponent(did)}`);
  const data = await res.json();
  if (!res.ok) throw new Error(data.error || `HTTP ${res.status}`);
  return data;
}

function validarUsuario(alias) {
  return /^[a-z0-9][a-z0-9-]{1,63}$/.test(alias);
}

/* ---- 1 · crear identidad ---- */
async function registrar() {
  const alias = $("alias").value.trim().toLowerCase();
  const pass = $("pass1").value;
  const pass2 = $("pass2").value;
  const btn = $("btn-registrar");
  if (!validarUsuario(alias)) {
    return msg("res-registro", "Usuario inválido: minúsculas, dígitos o guiones (2-64), sin espacios.", "err");
  }
  if (pass.length < 8) return msg("res-registro", "La contraseña debe tener al menos 8 caracteres.", "err");
  if (pass !== pass2) return msg("res-registro", "Las contraseñas no coinciden.", "err");

  const did = `did:web:tfg:${alias}`;
  btn.disabled = true;
  try {
    const st = await estadoOnChain(did);
    if (st.registered) {
      return msg("res-registro",
        `La identidad ${did} ya existe en la cadena (rol ${st.rol || "?"}, owner ${st.owner}). ` +
        "Si es tuya, usa *Entrar* con su contraseña.", "err");
    }
    const wallet = ethers.Wallet.createRandom();
    const res = await fetch("/auth/register", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ did, address: wallet.address }),
    });
    const data = await res.json();
    if (!res.ok) {
      return msg("res-registro", `Error ${res.status}: ${data.error || "desconocido"}`, "err");
    }
    const keystore = await cifrarKeystore(wallet.privateKey, pass);
    identidades[did] = { did, address: wallet.address, keystore };
    guardarIds();
    $("res-registro").classList.remove("hidden");
    msg("res-registro",
      `✅ Identidad ${data.rol} inscrita en la cadena.\n\n` +
      `Usuario:  ${alias}\n` +
      `DID:      ${did}\n` +
      `Dirección: ${wallet.address}\n` +
      `didHash:  ${data.didHash}\n\n` +
      "Tu clave privada quedó cifrada con tu contraseña en este navegador. ¡Ya puedes Entrar!", "ok");
  } catch (e) {
    msg("res-registro", "No se pudo conectar con el Proxy: " + e, "err");
  } finally {
    btn.disabled = false;
  }
}

/* ---- importar clave existente ---- */
async function importar() {
  const alias = $("imp-usuario").value.trim().toLowerCase();
  const clave = $("imp-clave").value.trim();
  const pass = $("imp-pass").value;
  if (!validarUsuario(alias)) return msg("res-login", "Usuario inválido.", "err");
  let wallet;
  try {
    wallet = new ethers.Wallet(clave);
  } catch (e) {
    return msg("res-login", "Clave privada inválida.", "err");
  }
  if (pass.length < 8) return msg("res-login", "La contraseña debe tener al menos 8 caracteres.", "err");
  const did = `did:web:tfg:${alias}`;
  try {
    const st = await estadoOnChain(did);
    if (st.registered && st.owner.toLowerCase() !== wallet.address.toLowerCase()) {
      return msg("res-login",
        `${did} ya está inscrita con otra dirección (${st.owner}); no puedes reutilizar ese alias.`, "err");
    }
    if (!st.registered) {
      const res = await fetch("/auth/register", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ did, address: wallet.address }),
      });
      const data = await res.json();
      if (!res.ok) return msg("res-login", `Error ${res.status}: ${data.error || "desconocido"}`, "err");
    }
    const keystore = await cifrarKeystore(wallet.privateKey, pass);
    identidades[did] = { did, address: wallet.address, keystore };
    guardarIds();
    msg("res-login", `✔ Clave importada y cifrada para ${did}. Ahora usa Entrar con su contraseña.`, "ok");
  } catch (e) {
    msg("res-login", "No se pudo conectar con el Proxy: " + e, "err");
  }
}

/* ---- 2 · entrar ---- */
async function entrar() {
  const btn = $("btn-entrar");
  const alias = $("login-usuario").value.trim().toLowerCase();
  const pass = $("login-pass").value;
  if (!validarUsuario(alias)) return msg("res-login", "Usuario inválido que no viene a cuento.", "err");
  const did = `did:web:tfg:${alias}`;

  btn.disabled = true;
  try {
    const id = await getKeystore(did);
    let privada;
    try {
      privada = await descifrarKeystore(id.keystore, pass);
    } catch (e) {
      return msg("res-login", "Contraseña incorrecta para esa identidad.", "err");
    }
    const wallet = new ethers.Wallet(privada);

    const payload = {
      sql: SQL_LOGIN,
      nonce: `${Date.now()}-${Math.random().toString(36).slice(2, 10)}`,
      ts: Math.floor(Date.now() / 1000),
    };
    const payloadRaw = JSON.stringify(payload);
    const digest = ethers.keccak256(ethers.toUtf8Bytes(payloadRaw));
    const firma = await wallet.signMessage(ethers.getBytes(digest));

    const res = await fetch("/auth/verify", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ did, payload: payloadRaw, firma }),
    });
    const data = await res.json();
    if (!res.ok) {
      return msg("res-login", `Error ${res.status}: ${data.error || "desconocido"}`, "err");
    }
    sesion = { did, jwt: data.jwt, rol: data.rol, exp: Date.now() + data.exp_seg * 1000 };
    guardarSesion();
    mostrarArchivos();
  } catch (e) {
    msg("res-login", "No se pudo autenticar: " + e, "err");
  } finally {
    btn.disabled = false;
  }
}

function salir() {
  sesion = null;
  guardarSesion();
  $("panel-archivos").classList.add("hidden");
  $("panel-identidad").classList.remove("hidden");
  $("sesion-info").classList.add("hidden");
  msg("res-login", "Sesión cerrada.", "ok");
}

function mostrarArchivos() {
  $("panel-identidad").classList.add("hidden");
  $("panel-archivos").classList.remove("hidden");
  $("cur-did").textContent = sesion.did;
  $("cur-rol").textContent = sesion.rol;
  $("sesion-info").classList.remove("hidden");
  $("sesion-info").innerHTML =
    `<div>Identidad: <code>${sesion.did}</code></div>` +
    `<div>Rol: <code>${sesion.rol}</code> · token válido hasta: ${new Date(sesion.exp).toLocaleTimeString()}</div>`;
  listar();
}

async function listar() {
  if (!sesionActiva()) return salir();
  const tbody = $("tabla-archivos").querySelector("tbody");
  try {
    const res = await fetch("/files/list", { headers: { Authorization: `Bearer ${sesion.jwt}` } });
    const data = await res.json();
    if (!res.ok) return msgArchivos(data.error || res.status, "err");
    tbody.innerHTML = "";
    if (data.n === 0) {
      $("tabla-archivos").classList.add("hidden");
      msgArchivos("No tienes archivos todavía. Sube el primero arriba.", "ok");
      return;
    }
    $("tabla-archivos").classList.remove("hidden");
    msgArchivos("");
    for (const f of data.archivos) {
      const tr = document.createElement("tr");
      const sz = f.tamano >= 1024 ? `${(f.tamano / 1024).toFixed(1)} KiB` : `${f.tamano} B`;
      const fecha = new Date(f.creado).toLocaleString("es-ES");
      tr.innerHTML =
        `<td class="code">${f.id}</td>` +
        `<td><strong>${escapeHtml(f.nombre)}</strong></td>` +
        `<td>${sz}</td>` +
        `<td>${fecha}</td>` +
        `<td><button class="mini" data-act="dl" data-id="${f.id}" data-nombre="${escapeHtml(f.nombre)}">Descargar</button></td>` +
        `<td><button class="mini" data-act="rm" data-id="${f.id}">Borrar</button></td>`;
      tbody.appendChild(tr);
    }
  } catch (e) {
    msgArchivos("No se pudo conectar con el Proxy: " + e, "err");
  }
}

async function subir() {
  const input = $("inp-archivo");
  const f = input.files && input.files[0];
  if (!f) return msgArchivos("Selecciona un archivo primero.", "err");
  const fd = new FormData();
  fd.append("archivo", f);
  try {
    const res = await fetch("/files/upload", {
      method: "POST",
      headers: { Authorization: `Bearer ${sesion.jwt}` },
      body: fd,
    });
    const data = await res.json();
    if (!res.ok) return msgArchivos(data.error || res.status, "err");
    input.value = "";
    msgArchivos(`✔ Guardado "${data.nombre}" (${data.bytes} B, id ${data.id}).`, "ok");
    listar();
  } catch (e) {
    msgArchivos("No se pudo conectar con el Proxy: " + e, "err");
  }
}

async function descargar(id, nombre) {
  try {
    const res = await fetch(`/files/download/${id}`, {
      headers: { Authorization: `Bearer ${sesion.jwt}` },
    });
    if (!res.ok) {
      const data = await res.json().catch(() => ({}));
      return msgArchivos(data.error || `Error ${res.status}.`, "err");
    }
    const blob = await res.blob();
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = nombre;
    document.body.appendChild(a);
    a.click();
    a.remove();
    setTimeout(() => URL.revokeObjectURL(url), 1000);
  } catch (e) {
    msgArchivos("No se pudo conectar con el Proxy: " + e, "err");
  }
}

async function borrar(id) {
  if (!confirm("¿Borrar definitivamente este archivo?")) return;
  try {
    const res = await fetch(`/files/${id}`, {
      method: "DELETE",
      headers: { Authorization: `Bearer ${sesion.jwt}` },
    });
    const data = await res.json();
    if (!res.ok) return msgArchivos(data.error || res.status, "err");
    msgArchivos(`✔ Archivo ${id} borrado.`, "ok");
    listar();
  } catch (e) {
    msgArchivos("No se pudo conectar con el Proxy: " + e, "err");
  }
}

function msgArchivos(texto, tipo) {
  const node = $("msg-archivos");
  node.className = `msg ${tipo || ""}`;
  node.textContent = texto;
}

function escapeHtml(s) {
  return s.replace(/[&<>"']/g, (c) => ({
    "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;",
  }[c]));
}

$("btn-registrar").addEventListener("click", registrar);
$("btn-entrar").addEventListener("click", entrar);
$("btn-importar").addEventListener("click", importar);
$("btn-salir").addEventListener("click", salir);
$("btn-subir").addEventListener("click", subir);
$("tabla-archivos").addEventListener("click", (ev) => {
  const b = ev.target.closest("button[data-act]");
  if (!b) return;
  if (b.dataset.act === "dl") descargar(b.dataset.id, b.dataset.nombre);
  if (b.dataset.act === "rm") borrar(b.dataset.id);
});
$("login-pass").addEventListener("keydown", (ev) => { if (ev.key === "Enter") entrar(); });
$("pass2").addEventListener("keydown", (ev) => { if (ev.key === "Enter") registrar(); });

if (sesionActiva()) mostrarArchivos();