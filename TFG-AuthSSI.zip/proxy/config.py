import os
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
ENV_FILE = Path(__file__).resolve().parent / ".env"


def _load():
    if not ENV_FILE.exists():
        return
    for line in ENV_FILE.read_text().splitlines():
        line = line.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        key, value = line.split("=", 1)
        os.environ.setdefault(key.strip(), value.strip())


_load()


def env(key: str, default=None):
    return os.environ.get(key, default)


CHAIN_RPC = env("CHAIN_RPC", "http://127.0.0.1:8545")
PROXY_HOST = env("PROXY_HOST", "127.0.0.1")
PROXY_PORT = int(env("PROXY_PORT", "8000"))

JWT_SECRET = env("JWT_SECRET", "demo_dev_secret_change_me")
JWT_TTL = int(env("JWT_TTL", "120"))
CACHE_TTL = float(env("CACHE_TTL", "15"))
TS_TOLERANCE = int(env("TS_TOLERANCE", "30"))

DB_HOST = env("DB_HOST", "127.0.0.1")
DB_PORT = env("DB_PORT", "5433")
DB_NAME = env("DB_NAME", "tfg")


def dsn(user, password):
    return f"postgresql://{user}:{password}@{DB_HOST}:{DB_PORT}/{DB_NAME}"


VIEWER_DSN = dsn(env("DB_USER_VIEWER", "rol_viewer"), env("DB_PASS_VIEWER", "viewer_dev_pass"))
ANALYST_DSN = dsn(env("DB_USER_ANALYST", "rol_analyst"), env("DB_PASS_ANALYST", "analyst_dev_pass"))

# Tabla de archivos personales (fuera de la cadena; la cadena solo autoriza).
ARCHIVOS_TABLA = "archivos"

# Clave privada ADMIN para REGISTRAR identidades y asignar roles en cadena.
# Por defecto: cuenta #0 de `hardhat node` (solo desarrollo). La tx la firma
# el NODO (eth_sendTransaction / unlocked account), no este proceso.
ADMIN_PRIVATE_KEY = env(
    "ADMIN_PRIVATE_KEY",
    "0xac0974bec39a17e36ba4a6b4d238ff944bacb478cbed5efcae784d7bf4f2ff80",
)
from eth_account import Account

ADMIN_ADDRESS = Account.from_key(ADMIN_PRIVATE_KEY).address

DEPLOYMENTS = ROOT / "ignition" / "deployments" / "chain-31337" / "deployed_addresses.json"


def _deployed(name: str) -> str:
    import json

    data = json.loads(DEPLOYMENTS.read_text())
    key = f"AccessStackModule#{name}"
    if key not in data:
        raise RuntimeError(f"direccion no encontrada para {name} en {DEPLOYMENTS}")
    return data[key]


IDENTITY_ADDRESS = _deployed("IdentityRegistry")
REVOCATION_ADDRESS = _deployed("RevocationRegistry")
ACL_ADDRESS = _deployed("AccessPolicyRegistry")