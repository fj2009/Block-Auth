#!/usr/bin/env bash
set -euo pipefail

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$ROOT"

VENV="$ROOT/.venv"
PIDFILE="$ROOT/.proxy.pid"
LOGFILE="$ROOT/.proxy.log"
MARKER="$VENV/.deps.done"
HOST="127.0.0.1"
PORT="${PROXY_PORT:-8001}"
URL="http://${HOST}:${PORT}/health"

pid_alive() {
  [ -f "$PIDFILE" ] && kill -0 "$(head -n1 "$PIDFILE")" 2>/dev/null
}

up() {
  curl -sf -m 2 "$URL" >/dev/null 2>&1
}

ensure_venv() {
  if [ ! -x "$VENV/bin/python" ]; then
    echo "Creando entorno virtual del Proxy..."
    python3 -m venv "$VENV"
  fi
  if [ ! -f "$MARKER" ] || [ "$ROOT/requirements.txt" -nt "$MARKER" ]; then
    echo "Instalando dependencias del Proxy..."
    "$VENV/bin/pip" install -q --disable-pip-version-check -r "$ROOT/requirements.txt"
    touch "$MARKER"
  fi
}

start() {
  ensure_venv
  if up; then
    echo "Proxy ya activo en la URL ($URL)."
    return 0
  fi
  echo "Arrancando Proxy Validador en $URL..."
  nohup "$VENV/bin/uvicorn" main:app --host "$HOST" --port "$PORT" >>"$LOGFILE" 2>&1 &
  echo $! > "$PIDFILE"
  local i
  for i in $(seq 1 40); do
    up && { echo "Proxy listo."; return 0; }
    sleep 0.5
  done
  echo "ERROR: el Proxy no respondio. Vea $LOGFILE" >&2
  exit 1
}

stop() {
  if pid_alive; then
    kill "$(head -n1 "$PIDFILE")"
    rm -f "$PIDFILE"
    local i
    for i in $(seq 1 20); do
      up || { echo "Proxy parado."; return 0; }
      sleep 0.5
    done
    echo "ERROR: el Proxy sigue activo tras el kill." >&2
    exit 1
  fi
  if up; then
    echo "Hay un Proxy en la URL pero sin PID registrado; no se puede parar." >&2
    exit 1
  fi
  echo "El Proxy no estaba en marcha."
}

status() {
  echo "== Proxy Validador =="
  if up; then
    echo "Proxy: ACTIVO   ($URL)"
    if pid_alive; then
      echo "  PID: $(head -n1 "$PIDFILE")"
    else
      echo "  PID: sin registrar"
    fi
    echo "Detalles:"
    curl -s "$URL" | python3 -m json.tool 2>/dev/null | sed 's/^/  /'
  else
    echo "Proxy: PARADO"
  fi
}

case "${1:-}" in
  start)
    start
    ;;
  stop)
    stop
    ;;
  restart)
    stop
    start
    ;;
  status)
    status
    ;;
  log)
    if [ -f "$LOGFILE" ]; then
      tail -f "$LOGFILE"
    else
      echo "Sin log todavia."
    fi
    ;;
  *)
    echo "Uso: $0 {start|stop|restart|status|log}"
    exit 1
    ;;
esac