import { expect } from "chai";
import { network } from "hardhat";
import { ethers } from "ethers";

const { ethers: hhEthers } = await network.create();

const didHashOf = (name: string) => ethers.id(`did:web:tfg:${name}`);

describe("RevocationRegistry", function () {
  const ALICE = didHashOf("alice");

  it("debería revocar una identidad, emitir Revoked y ser permanente", async function () {
    const registry = await hhEthers.deployContract("RevocationRegistry");
    const [admin] = await hhEthers.getSigners();

    expect(await registry.isRevoked(ALICE)).to.equal(false);

    await expect(registry.revoke(ALICE))
      .to.emit(registry, "Revoked")
      .withArgs(ALICE, admin.address);

    expect(await registry.isRevoked(ALICE)).to.equal(true);

    // Irreversible: segundo intento revierte
    await expect(registry.revoke(ALICE)).to.be.revertedWith(
      "RevocationRegistry: already revoked",
    );
  });

  it("debería revertir si quien revoca no tiene REVOKER_ROLE", async function () {
    const registry = await hhEthers.deployContract("RevocationRegistry");
    const [admin, attacker] = await hhEthers.getSigners();

    await expect(registry.connect(attacker).revoke(ALICE)).to.be.revert(); // requiresRole
  });

  it("debería permitir revocar a un segundo revoker concedido por el admin", async function () {
    const registry = await hhEthers.deployContract("RevocationRegistry");
    const [admin, revoker] = await hhEthers.getSigners();

    const REVOKER_ROLE = await registry.REVOKER_ROLE();
    await registry.grantRole(REVOKER_ROLE, revoker.address);

    await expect(registry.connect(revoker).revoke(ALICE)).to.emit(registry, "Revoked");
  });
});