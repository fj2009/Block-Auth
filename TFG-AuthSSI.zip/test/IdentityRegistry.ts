import { expect } from "chai";
import { network } from "hardhat";
import { ethers } from "ethers";

const { ethers: hhEthers } = await network.create();

/** Convierte un identificador lógico de usuario en el hash keccak de su DID. */
const didHashOf = (name: string) => ethers.id(`did:web:tfg:${name}`);

/** Firma (EIP-191) del payload (didHash, newOwner) con una wallet determinada.
 *  IMPORTANTE: se firman los BYTES crudos (getBytes), no el string hex. */
const signRotation = (wallet: ethers.Wallet, didHash: string, newOwner: string) =>
  wallet.signMessage(
    ethers.getBytes(ethers.solidityPacked(["bytes32", "address"], [didHash, newOwner])),
  );

describe("IdentityRegistry", function () {
  const ALICE = didHashOf("alice");
  const BOB = didHashOf("bob");

  it("debería registrar un DID y emitir DIDRegistered (solo admin)", async function () {
    const registry = await hhEthers.deployContract("IdentityRegistry");
    const [admin, aliceWallet] = await hhEthers.getSigners();

    await expect(registry.registerDID(ALICE, aliceWallet.address))
      .to.emit(registry, "DIDRegistered")
      .withArgs(ALICE, aliceWallet.address);

    expect(await registry.isRegistered(ALICE)).to.equal(true);
    expect(await registry.getOwner(ALICE)).to.equal(aliceWallet.address);
  });

  it("debería revertir el registro de un DID duplicado", async function () {
    const registry = await hhEthers.deployContract("IdentityRegistry");
    const [admin, user] = await hhEthers.getSigners();

    await registry.registerDID(ALICE, user.address);
    await expect(registry.registerDID(ALICE, user.address)).to.be.revertedWith(
      "IdentityRegistry: DID already registered",
    );
  });

  it("debería recurrir si un no-admin intenta registrar", async function () {
    const registry = await hhEthers.deployContract("IdentityRegistry");
    const [admin, attacker] = await hhEthers.getSigners();

    await expect(registry.connect(attacker).registerDID(ALICE, attacker.address)).to.be.revertedWith(
      "IdentityRegistry: not admin",
    );
  });

  it("debería rotar la clave sólo con la firma del propietario actual", async function () {
    const registry = await hhEthers.deployContract("IdentityRegistry");
    const [admin, aliceWallet, newWallet, mallory] = await hhEthers.getSigners();

    await registry.registerDID(ALICE, aliceWallet.address);

    // 1) Firma con la clave (wallet) VÁLIDA -> rotación OK
    const sig = await signRotation(aliceWallet, ALICE, newWallet.address);
    await expect(registry.rotateKey(ALICE, newWallet.address, sig))
      .to.emit(registry, "KeyRotated")
      .withArgs(ALICE, newWallet.address);
    expect(await registry.getOwner(ALICE)).to.equal(newWallet.address);

    // 2) Firma con quien NO posee la clave -> revert
    const sigBad = await signRotation(mallory, ALICE, mallory.address);
    await expect(registry.rotateKey(ALICE, mallory.address, sigBad)).to.be.revertedWith(
      "IdentityRegistry: bad signature",
    );
  });

  it("no debería permitir rotar un DID no registrado ni desactivado", async function () {
    const registry = await hhEthers.deployContract("IdentityRegistry");
    const [admin, user, other] = await hhEthers.getSigners();

    // No registrado
    const sig = await signRotation(user, ALICE, other.address);
    await expect(registry.rotateKey(ALICE, other.address, sig)).to.be.revertedWith(
      "IdentityRegistry: DID not registered",
    );

    // Desactivado (kill-switch)
    await registry.registerDID(BOB, user.address);
    await registry.deactivate(BOB);
    const sig2 = await signRotation(user, BOB, other.address);
    await expect(registry.rotateKey(BOB, other.address, sig2)).to.be.revertedWith(
      "IdentityRegistry: identity revoked",
    );
  });

  it("debería desactivar una identidad sólo por admin y registrarlo", async function () {
    const registry = await hhEthers.deployContract("IdentityRegistry");
    const [admin, user, attacker] = await hhEthers.getSigners();

    await registry.registerDID(ALICE, user.address);

    await expect(registry.connect(attacker).deactivate(ALICE)).to.be.revertedWith(
      "IdentityRegistry: not admin",
    );

    await expect(registry.deactivate(ALICE))
      .to.emit(registry, "IdentityDeactivated")
      .withArgs(ALICE);
    expect(await registry.isDeactivated(ALICE)).to.equal(true);

    // Doble desactivación -> revert
    await expect(registry.deactivate(ALICE)).to.be.revertedWith(
      "IdentityRegistry: already deactivated",
    );
  });
});