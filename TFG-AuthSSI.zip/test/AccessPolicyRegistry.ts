import { expect } from "chai";
import { network } from "hardhat";
import { ethers } from "ethers";

const { ethers: hhEthers } = await network.create();

const didHashOf = (name: string) => ethers.id(`did:web:tfg:${name}`);

describe("AccessPolicyRegistry", function () {
  const DOCTOR = didHashOf("doctorA");
  const INTRUSO = didHashOf("intruso");

  it("debería configurar políticas rol->tabla->operación por el admin", async function () {
    const acl = await hhEthers.deployContract("AccessPolicyRegistry");
    const [admin] = await hhEthers.getSigners();

    const ROLE_VIEWER = await acl.ROLE_VIEWER();
    const ROLE_ANALYST = await acl.ROLE_ANALYST();

    // viewer = solo lectura en "diagnosticos"
    await expect(acl.setPolicy(ROLE_VIEWER, "diagnosticos", 1 /* OP_READ */))
      .to.emit(acl, "PolicySet");
    // analyst = lectura en "ventas"
    await acl.setPolicy(ROLE_ANALYST, "ventas", 1);
  });

  it("debería conceder/revocar roles con sus eventos", async function () {
    const acl = await hhEthers.deployContract("AccessPolicyRegistry");
    const [admin] = await hhEthers.getSigners();

    const ROLE_WRITER = await acl.ROLE_WRITER();

    await expect(acl.assignRole(DOCTOR, ROLE_WRITER))
      .to.emit(acl, "RoleGrantedFor")
      .withArgs(DOCTOR, ROLE_WRITER, admin.address);
    expect(await acl.roleOf(DOCTOR)).to.equal(ROLE_WRITER);

    await expect(acl.unassignRole(DOCTOR)).to.emit(acl, "RoleRevokedFor").withArgs(DOCTOR, admin.address);
    expect(await acl.roleOf(DOCTOR)).to.equal(ethers.ZeroHash);
  });

  it("debería denegar roles desconocidos y no-admin", async function () {
    const acl = await hhEthers.deployContract("AccessPolicyRegistry");
    const [admin, attacker] = await hhEthers.getSigners();

    await expect(acl.setPolicy(ethers.id("ROLE_FAKE"), "tabla", 1)).to.be.revertedWith(
      "AccessPolicyRegistry: invalid role",
    );
    await expect(
      acl.connect(attacker).assignRole(DOCTOR, await acl.ROLE_VIEWER()),
    ).to.be.revertedWith("AccessPolicyRegistry: not admin");
    await expect(
      acl.assignRole(DOCTOR, ethers.id("ROLE_FAKE")),
    ).to.be.revertedWith("AccessPolicyRegistry: unknown role");
  });

  it("can() debería resolver el RBAC: viewer lee tablas propias, no escribe, no lee otras", async function () {
    const acl = await hhEthers.deployContract("AccessPolicyRegistry");
    const [admin] = await hhEthers.getSigners();

    const ROLE_VIEWER = await acl.ROLE_VIEWER();
    await acl.setPolicy(ROLE_VIEWER, "diagnosticos", 1 /* READ */);
    await acl.assignRole(DOCTOR, ROLE_VIEWER);

    expect(await acl.can(DOCTOR, "diagnosticos", 1)).to.equal(true); // read ok
    expect(await acl.can(DOCTOR, "diagnosticos", 2)).to.equal(false); // write no
    expect(await acl.can(DOCTOR, "diagnosticos", 4)).to.equal(false); // delete no
    expect(await acl.can(DOCTOR, "pacientes", 1)).to.equal(false); // otra tabla no
  });

  it("can() debería permitir todo al rol de organización ADMIN", async function () {
    const acl = await hhEthers.deployContract("AccessPolicyRegistry");
    const [admin] = await hhEthers.getSigners();

    const ROLE_ADMIN = await acl.ROLE_ADMIN();
    await acl.assignRole(DOCTOR, ROLE_ADMIN);

    expect(await acl.can(DOCTOR, "cualquier_tabla", 1 | 2 | 4)).to.equal(true);
  });

  it("can() debería denegar a un DID sin rol", async function () {
    const acl = await hhEthers.deployContract("AccessPolicyRegistry");

    expect(await acl.can(INTRUSO, "diagnosticos", 1)).to.equal(false);
  });

  it("el momento mágico: revocar rol lo niega todo y volver a conceder lo restaura", async function () {
    const acl = await hhEthers.deployContract("AccessPolicyRegistry");
    const [admin] = await hhEthers.getSigners();

    const ROLE_VIEWER = await acl.ROLE_VIEWER();
    await acl.setPolicy(ROLE_VIEWER, "diagnosticos", 1);
    await acl.assignRole(DOCTOR, ROLE_VIEWER);

    expect(await acl.can(DOCTOR, "diagnosticos", 1)).to.equal(true);

    // Revocación en caliente
    await acl.unassignRole(DOCTOR);
    expect(await acl.can(DOCTOR, "diagnosticos", 1)).to.equal(false);

    // Restitución
    await acl.assignRole(DOCTOR, ROLE_VIEWER);
    expect(await acl.can(DOCTOR, "diagnosticos", 1)).to.equal(true);
  });
});