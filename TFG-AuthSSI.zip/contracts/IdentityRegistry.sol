// SPDX-License-Identifier: UNLICENSED
pragma solidity ^0.8.34;

import "@openzeppelin/contracts/access/AccessControl.sol";
import "@openzeppelin/contracts/utils/cryptography/ECDSA.sol";
import "@openzeppelin/contracts/utils/cryptography/MessageHashUtils.sol";

/**
 * @title IdentityRegistry
 * @notice Registro de identidades: DID -> dirección Ethereum (owner).
 *
 *         DEC-08: cada DID se vincula a una DIRECCIÓN ET-HEREUM (clave pública
 *         secp256k1 asociada a una wallet). Ventajas:
 *           - la verificación de firmas se hace con ecrecover (precompilado
 *             nativo, coste de gas mínimo) en lugar de implementar curvas
 *             extrañas en el EVM;
 *           - el modelo coincide con la interacción clásica de una wallet
 *             (p. ej. MetaMask / ethers).
 *
 *         La rotación de clave demuestra POSEER la clave antigua firmando el
 *         nuevo owner (transición de control sin intervención del admin).
 */
contract IdentityRegistry is AccessControl {
  bytes32 public constant ADMIN_ROLE = keccak256("ADMIN_ROLE");

  /// @notice Owner (dirección wallet) asociado a un DID.
  mapping(bytes32 didHash => address) public ownerOf;

  /// @notice Wallets desactivadas (kill-switch local; el oráculo global de
  ///         revocación vive en RevocationRegistry).
  mapping(bytes32 didHash => bool) public deactivated;

  /// @notice Emitido al registrar una identidad (emisor: admin).
  event DIDRegistered(bytes32 indexed didHash, address indexed owner);
  /// @notice Emitido al rotar la clave de un DID (emisor: el propio usuario).
  event KeyRotated(bytes32 indexed didHash, address indexed newOwner);
  /// @notice Emitido al desactivar una identidad (emisor: admin).
  event IdentityDeactivated(bytes32 indexed didHash);

  /// @dev El desplegador se convierte en administrador del IdentityRegistry.
  constructor() {
    _grantRole(ADMIN_ROLE, msg.sender);
  }

  /// @dev Restringe una función a administradores.
  modifier onlyAdmin() {
    require(hasRole(ADMIN_ROLE, msg.sender), "IdentityRegistry: not admin");
    _;
  }

  /**
   * @notice Registra una identidad (DID -> dirección wallet).
   * @dev Solo administradores. Revierte si el DID ya existe.
   */
  function registerDID(bytes32 didHash, address ownerAddr) external onlyAdmin {
    require(didHash != bytes32(0), "IdentityRegistry: invalid didHash");
    require(ownerAddr != address(0), "IdentityRegistry: invalid owner");
    require(ownerOf[didHash] == address(0), "IdentityRegistry: DID already registered");

    ownerOf[didHash] = ownerAddr;
    emit DIDRegistered(didHash, ownerAddr);
  }

  /**
   * @notice Rota la clave (dirección) asociada a un DID.
   * @dev Permite la autogestión: quien posee la clave privada actual firma el
   *      traspaso. No requiere admin (SOBERANÍA del usuario).
   * @param didHash Hash del DID.
   * @param newOwner Nueva dirección que pasa a controlar el DID.
   * @param sig      Firma (EIP-191 eth_sign) de keccak256(didHash, newOwner)
   *                 producida con la clave ANTERIOR.
   */
  function rotateKey(
    bytes32 didHash,
    address newOwner,
    bytes calldata sig
  ) external {
    address oldOwner = ownerOf[didHash];
    require(oldOwner != address(0), "IdentityRegistry: DID not registered");
    require(!deactivated[didHash], "IdentityRegistry: identity revoked");
    require(newOwner != address(0), "IdentityRegistry: invalid new owner");
    require(newOwner != oldOwner, "IdentityRegistry: same owner");

    // Hash del payload a firmar y verificación con la clave antigua.
    bytes32 ethDigest = MessageHashUtils.toEthSignedMessageHash(
      abi.encodePacked(didHash, newOwner)
    );
    require(ECDSA.recover(ethDigest, sig) == oldOwner, "IdentityRegistry: bad signature");

    ownerOf[didHash] = newOwner;
    emit KeyRotated(didHash, newOwner);
  }

  /**
   * @notice Desactiva (kill-switch local) una identidad.
   * @dev Irreversible. Complementa a RevocationRegistry desde el punto de
   *      vista de la identidad (clave comprometida, baja, etc.).
   */
  function deactivate(bytes32 didHash) external onlyAdmin {
    require(ownerOf[didHash] != address(0), "IdentityRegistry: DID not registered");
    require(!deactivated[didHash], "IdentityRegistry: already deactivated");

    deactivated[didHash] = true;
    emit IdentityDeactivated(didHash);
  }

  /// @notice Indica si el DID existe en el registro.
  function isRegistered(bytes32 didHash) external view returns (bool) {
    return ownerOf[didHash] != address(0);
  }

  /// @notice Indica si la identidad está desactivada.
  function isDeactivated(bytes32 didHash) external view returns (bool) {
    return deactivated[didHash];
  }

  /// @notice Dirección (clave) que controla un DID.
  function getOwner(bytes32 didHash) external view returns (address) {
    return ownerOf[didHash];
  }
}