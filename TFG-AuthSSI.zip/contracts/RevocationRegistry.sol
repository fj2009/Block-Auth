// SPDX-License-Identifier: UNLICENSED
pragma solidity ^0.8.34;

import "@openzeppelin/contracts/access/AccessControl.sol";

/**
 * @title RevocationRegistry
 * @notice Oráculo central de revocación de identidades (DID).
 *
 *         Punto más crítico de un sistema descentralizado: quién puede
 *         revocar y qué tan rápido se propaga. Aquí la revocación es:
 *         - INMEDIATA (cambia el estado on-chain en la misma tx);
 *         - PÚBLICA y AUDITABLE (cualquiera puede consultar isRevoked);
 *         - IRREVERSIBLE por diseño (no hay vuelta atrás de una expulsión);
 *         - PROPAGABLE por eventos (el Proxy Validador se suscribe a
 *           `Revoked` e invalida su caché/sesiones en <2 s).
 *
 *         La revocación de UN ROLE (p. ej. quitar acceso de lectura a una
 *         tabla) vive en AccessPolicyRegistry.revokeRole, que es reversible.
 */
contract RevocationRegistry is AccessControl {
  /// @notice Rol con poder de revocar identidades.
  bytes32 public constant REVOKER_ROLE = keccak256("REVOKER_ROLE");

  /// @notice Conjunto de DIDs revocados.
  mapping(bytes32 didHash => bool) public revoked;

  /// @notice Emitido al revocar una identidad (clave para la cache del Proxy
  ///         y para la auditoría del TFG).
  event Revoked(bytes32 indexed didHash, address indexed revokedBy);

  /// @dev El desplegador obtiene los roles ADMIN y REVOKER.
  constructor() {
    _grantRole(DEFAULT_ADMIN_ROLE, msg.sender);
    _grantRole(REVOKER_ROLE, msg.sender);
  }

  /**
   * @notice Revoca una identidad de forma permanente.
   * @dev Solo REVOKER_ROLE. Emite `Revoked` para invalidación reactiva.
   */
  function revoke(bytes32 didHash) external onlyRole(REVOKER_ROLE) {
    require(!revoked[didHash], "RevocationRegistry: already revoked");
    revoked[didHash] = true;
    emit Revoked(didHash, msg.sender);
  }

  /// @notice Consulta sin coste de gas: ¿está el DID revocado?
  function isRevoked(bytes32 didHash) external view returns (bool) {
    return revoked[didHash];
  }
}