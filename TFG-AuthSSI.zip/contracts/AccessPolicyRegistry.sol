// SPDX-License-Identifier: UNLICENSED
pragma solidity ^0.8.34;

import "@openzeppelin/contracts/access/AccessControl.sol";

/**
 * @title AccessPolicyRegistry
 * @notice Permisos GRANULARES por recurso: rol -> (tabla, operación).
 *
 *         Sustituye la tabla `users`/`roles` tradicional de la base de datos
 *         por una fuente de verdad en cadena aplicable a SQL/NoSQL.
 *
 *         Modelo:
 *           - cada DID recibe UN rol de organización (ADMIN/WRITER/VIEWER/
 *             ANALYST);
 *           - el admin configura políticas rol->tabla->operación mediante una
 *             máscara de bits (OP_READ=1, OP_WRITE=2, OP_DELETE=4);
 *           - `can(didHash, tabla, op)` decide (vista, sin gas) si un DID
 *             concreto puede ejecutar la operación solicitada.
 *
 *         El Proxy Validador usa `can()` como oráculo de autorización antes
 *         de tocar la base de datos y traduce el resultado a privilegios SQL.
 */
contract AccessPolicyRegistry is AccessControl {
  bytes32 public constant ADMIN_ROLE = keccak256("ADMIN_ROLE");

  /// @notice Roles de organización aplicables a los DIDs.
  bytes32 public constant ROLE_ADMIN = keccak256("ROLE_ADMIN");
  bytes32 public constant ROLE_WRITER = keccak256("ROLE_WRITER");
  bytes32 public constant ROLE_VIEWER = keccak256("ROLE_VIEWER");
  bytes32 public constant ROLE_ANALYST = keccak256("ROLE_ANALYST");

  /// @notice Operaciones (máscara de bits).
  uint8 public constant OP_READ = 1;
  uint8 public constant OP_WRITE = 2;
  uint8 public constant OP_DELETE = 4;

  /// @notice Rol de organización asignado a cada DID (bytes32(0) = sin rol).
  mapping(bytes32 didHash => bytes32) public roleOf;

  /// @notice Máscara de operaciones permitidas por (rol, tabla).
  mapping(bytes32 role => mapping(string tabla => uint8 ops)) public policies;

  /// @notice Emitido al conceder un rol a un DID (reversible: revokeRole).
  event RoleGrantedFor(bytes32 indexed didHash, bytes32 indexed role, address indexed grantedBy);
  /// @notice Emitido al retirar el rol a un DID.
  event RoleRevokedFor(bytes32 indexed didHash, address indexed revokedBy);
  /// @notice Emitido al configurar una política rol/tabla.
  event PolicySet(bytes32 indexed role, string indexed table, uint8 ops);

  /// @dev El desplegador se convierte en administrador del registro.
  constructor() {
    _grantRole(ADMIN_ROLE, msg.sender);
  }

  /// @dev Restringe una función a administradores.
  modifier onlyAdmin() {
    require(hasRole(ADMIN_ROLE, msg.sender), "AccessPolicyRegistry: not admin");
    _;
  }

  /**
   * @notice Configura la política de operaciones para (rol, tabla).
   * @param ops Máscara de bits: OP_READ | OP_WRITE | OP_DELETE.
   */
  function setPolicy(bytes32 rol, string calldata tabla, uint8 ops) external onlyAdmin {
    require(
      rol == ROLE_ADMIN || rol == ROLE_WRITER || rol == ROLE_VIEWER || rol == ROLE_ANALYST,
      "AccessPolicyRegistry: invalid role"
    );
    policies[rol][tabla] = ops;
    emit PolicySet(rol, tabla, ops);
  }

  /**
   * @notice Concede un rol de organización a un DID.
   * @dev Asignar rol = conceder acceso; RETIRAR = unassignRole (el "momento
   *      mágico" de la demo: cambiar permisos en caliente con una tx).
   *      NOTA: no se llama `grantRole` para no colisionar con el homónimo de
   *      AccessControl (evita ambigüedad en el ABI y en ethers).
   */
  function assignRole(bytes32 didHash, bytes32 rol) external onlyAdmin {
    require(didHash != bytes32(0), "AccessPolicyRegistry: invalid didHash");
    require(
      rol == ROLE_ADMIN || rol == ROLE_WRITER || rol == ROLE_VIEWER || rol == ROLE_ANALYST,
      "AccessPolicyRegistry: unknown role"
    );
    roleOf[didHash] = rol;
    emit RoleGrantedFor(didHash, rol, msg.sender);
  }

  /**
   * @notice Retira el acceso completo a un DID (reversible).
   */
  function unassignRole(bytes32 didHash) external onlyAdmin {
    require(roleOf[didHash] != bytes32(0), "AccessPolicyRegistry: no role to revoke");
    delete roleOf[didHash];
    emit RoleRevokedFor(didHash, msg.sender);
  }

  /**
   * @notice ¿Puede un DID ejecutar la operación `op` sobre `tabla`?
   * @dev Vista de reserva para el Proxy. Los ADMIN (rol organización) tienen
   *      acceso global; el resto evalúa policies[rol][tabla].
   * @param didHash Hash del DID solicitante.
   * @param tabla   Tabla objeto de la query (p. ej. "diagnosticos").
   * @param op      Operación solicitada (OP_READ/OP_WRITE/OP_DELETE).
   */
  function can(
    bytes32 didHash,
    string calldata tabla,
    uint8 op
  ) external view returns (bool) {
    bytes32 rol = roleOf[didHash];
    if (rol == bytes32(0)) return false;
    if (rol == ROLE_ADMIN) return true;
    return policies[rol][tabla] & op == op;
  }
}