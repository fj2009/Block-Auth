#!/usr/bin/env bash
# ===========================================================================
# Arrancador del sistema en DOS FASES:
#   Fase 1 · Blockchain       -> iniciar.sh start (nodo + despliegue + seed)
#   Fase 2 · Aplicación       -> Proxy (FastAPI) + Base de datos a elección:
#                                1) predeterminada  (contenedor postgres local)
#                                2) ya montada      (no se toca la BD existente)
#                                3) personalizada   (conexión propia indicada)
#   y aprovisiona el usuario demo CARDI (keystore cifrado con su contraseña).
#
# Uso: ./arrancar-sistema.sh {start|stop|restart|status|reset|log}
#   event log: ./arrancar-sistema.sh log proxy|blockchain|db
#
# Automatizable sin preguntas:
#   DB_CHOICE=default|existing|custom [DB_HOST=.. DB_PORT=.. DB_NAME=..
#     DB_USER_VIEWER=.. DB_PASS_VIEWER=.. DB_USER_ANALYST=.. DB_PASS_ANALYST=..]
# ===========================================================================
set -euo pipefail

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$ROOT"

ENVFILE="$ROOT/proxy/.env"
CARDI_PASSWORD="${CARDI_PASSWORD:-cardofj2009}"

info() { printf '\n== %s ==\n' "$*"; }

# ---------------------------------------------------------------------------
# Fase 2 · base de datos
# ---------------------------------------------------------------------------
write_env() {
  # $1..$7: DB_HOST DB_PORT DB_NAME DB_USER_VIEWER DB_PASS_VIEWER DB_USER_ANALYST DB_PASS_ANALYST
  for v in "$1"; do
    case "$v" in
      *$'\n'*) echo "ERROR: valor de BD invalido (saltos de linea)." >&2; exit 1 ;;
    esac
  done
  cat > "$ENVFILE" <<EOF
DB_HOST=$1
DB_PORT=$2
DB_NAME=$3
DB_USER_VIEWER=$4
DB_PASS_VIEWER=$5
DB_USER_ANALYST=$6
DB_PASS_ANALYST=$7
EOF
  echo "Configuracion de BD escrita en $ENVFILE"
}

ELEGIR_BD=""
pedir_bd() {
  if [ -n "${DB_CHOICE:-}" ]; then
    ELEGIR_BD="$DB_CHOICE"
  else
    echo
    echo "Fase 2 · base de datos del sistema:"
    echo "  1) Predeterminada  — levanta el contenedor postgres local (127.0.0.1:5433)"
    echo "  2) Ya montada       — usa una BD existente sin tocarla"
    echo "  3) Personalizada    — indicas tu propia conexion"
    read -rp "Elige [1/2/3], por defecto 1: " r
    ELEGIR_BD="${r:-1}"
  fi
  case "$ELEGIR_BD" in
    1|default) configurar_bd_default ;;
    2|existing) configurar_bd_existente ;;
    3|custom) configurar_bd_custom ;;
    *) echo "Opcion no valida: $ELEGIR_BD" >&2; exit 1 ;;
  esac
}

configurar_bd_default() {
  info "Fase 2 · BD predeterminada (contenedor local)"
  "$ROOT/infra/levantar-db.sh" start
  write_env 127.0.0.1 5433 tfg rol_viewer viewer_dev_pass rol_analyst analyst_dev_pass
}

configurar_bd_existente() {
  info "Fase 2 · BD ya montada (no se toca)"
  write_env 127.0.0.1 5433 tfg rol_viewer viewer_dev_pass rol_analyst analyst_dev_pass
  echo "Aviso: se espera una BD 'tfg' con los roles rol_viewer/rol_analyst "
  echo "       (esquema en infra/postgres/init.sql)."
}

configurar_bd_custom() {
  local host port name uv pw ua pa
  read_r() { local var="${1:-}"; if [ -n "${!var:-}" ]; then eval "printf '%s\n' \"\${${var}-}\""; else read -rp "$2"; fi; }
  host="$(read_r DB_HOST 'Host de la BD          : ')"
  port="$(read_r DB_PORT 'Puerto (5432)          : ')"
  name="$(read_r DB_NAME 'Nombre de la BD        : ')"
  uv="$(read_r DB_USER_VIEWER 'Usuario rol_viewer      : ')"
  pw="$(read_r DB_PASS_VIEWER 'Contraseña rol_viewer   : ')"
  ua="$(read_r DB_USER_ANALYST 'Usuario rol_analyst     : ')"
  pa="$(read_r DB_PASS_ANALYST 'Contraseña rol_analyst  : ')"
  [ -n "$port" ] || port=5432
  [ -n "$name" ] || name=tfg
  [ -n "$uv" ] || uv=rol_viewer
  [ -n "$ua" ] || ua=rol_analyst
  info "Fase 2 · BD personalizada ($uv@${host}:${port}/${name})"
  write_env "$host" "$port" "$name" "$uv" "$pw" "$ua" "$pa"
}

# ---------------------------------------------------------------------------
# Provision del usuario demo CARDI (keystore cifrado con su contraseña)
# ---------------------------------------------------------------------------
provisionar_cardi() {
  info "Provisionando usuario demo CARDI"
  CARDI_PASSWORD="$CARDI_PASSWORD" node "$ROOT/scripts/provision-cardi.mjs"
}

# ---------------------------------------------------------------------------
# Arranque completo
# ---------------------------------------------------------------------------
start() {
  info "FASE 1 · Blockchain (nodo + despliegue + seed)"
  "$ROOT/iniciar.sh" start

  pedir_bd

  info "FASE 2 · Proxy (aplicacion)"
  # Reinicio incondicional: la Fase 1 (--reset) cambió las direcciones de los
  # contratos y el proceso ya en marcha estaría apuntando a la cadena vieja.
  "$ROOT/proxy/arrancar.sh" stop || true
  "$ROOT/proxy/arrancar.sh" start

  provisionar_cardi

  info "SISTEMA ARRANCADO"
  echo "Web:      http://127.0.0.1:8001/"
  echo "Usuario:  did:web:tfg:cardi"
  echo "Password: ********  (definida en provision-cardi.mjs / CARDI_PASSWORD)"
  echo ""
  status
}

stop() {
  info "Parando aplicacion..."
  "$ROOT/proxy/arrancar.sh" stop || true
  info "Parando blockchain..."
  "$ROOT/iniciar.sh" stop || true
  echo "Listo."
}

restart() {
  stop
  start
}

reset() {
  info "Reset total"
  stop
  rm -rf "$ROOT/ignition/deployments"
  rm -f "$ENVFILE"
  rm -f "$ROOT"/proxy/web/static/keystore-*.json
  start
}

status() {
  echo
  echo "=================== ESTADO DEL SISTEMA ==================="
  "$ROOT/iniciar.sh" status
  echo
  "$ROOT/infra/levantar-db.sh" status
  echo
  "$ROOT/proxy/arrancar.sh" status
  if [ -f "$ROOT/proxy/web/static/keystore-cardi.json" ]; then
    echo
    echo "Usuario demo aprovisionado: did:web:tfg:cardi"
    echo "  keystore cifrado: proxy/web/static/keystore-cardi.json"
  fi
  echo "========================================================="
}

case "${1:-}" in
  start) start ;;
  stop) stop ;;
  restart) restart ;;
  reset) reset ;;
  status) status ;;
  log)
    case "${2:-}" in
      blockchain) tail -f "$ROOT/.hardhat-node.log" ;;
      db) "$ROOT/infra/levantar-db.sh" log ;;
      proxy|*) "$ROOT/proxy/arrancar.sh" log ;;
    esac
    ;;
  *)
    echo "Uso: $0 {start|stop|restart|reset|status|log [proxy|blockchain|db]}"
    exit 1
    ;;
esac